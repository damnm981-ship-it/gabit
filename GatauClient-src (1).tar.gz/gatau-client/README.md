# Gatau Client

> **Play Faster. Win Smarter.**  
> A feature-rich 1.8.9 PvP client built on Minecraft Forge.

---

## Requirements

| Requirement | Version |
|------------|---------|
| Java | 8 (JDK 8) |
| Minecraft | 1.8.9 |
| Forge | 1.8.9-11.15.1.2318-1.8.9 |
| Gradle | 2.14 |

---

## Building

```bash
# 1. Clone / download the project
# 2. Set up ForgeGradle (first run takes a while — it downloads MC/Forge)
./gradlew setupDecompWorkspace

# 3. (Optional) Generate IDE project files
./gradlew idea      # IntelliJ IDEA
./gradlew eclipse   # Eclipse

# 4. Build the mod JAR
./gradlew build

# Output: build/libs/GatauClient-1.0.0.jar
```

---

## Project Structure

```
src/main/java/com/gatauc/client/
├── GatauClient.java          ← Mod entry point / singleton
├── core/
│   ├── GatauCoreMod.java     ← FML core mod (ASM hooks, early loading)
│   └── GatauEventHooks.java  ← Forge→Gatau event bridge
├── event/
│   ├── Event.java            ← Base event class (cancellable)
│   ├── EventBus.java         ← Lightweight publish/subscribe bus
│   ├── EventHandler.java     ← @EventHandler annotation
│   └── events/               ← Concrete events (Render2D, Render3D, Update, Key, Chat, Packet…)
├── module/
│   ├── Module.java           ← Base module class
│   ├── ModuleManager.java    ← Registry + keybind dispatcher
│   ├── Category.java         ← RENDER / PLAYER / WORLD / PERFORMANCE / COSMETICS
│   ├── value/                ← BooleanValue, NumberValue, ModeValue
│   └── impl/
│       ├── render/           ← 15 render modules
│       ├── player/           ← 5 player modules
│       ├── world/            ← 4 world modules
│       ├── performance/      ← 6 performance modules
│       └── cosmetics/        ← Cape System + Cosmetic Manager
├── gui/
│   ├── clickgui/             ← ClickGUI (animated panels, search bar)
│   ├── hud/                  ← Drag-and-drop HUD Editor
│   ├── mainmenu/             ← Custom animated main menu
│   └── altmanager/           ← Local alt account manager
├── command/                  ← Chat command system (.toggle, .bind, .help, .save, .list)
├── keybind/                  ← KeybindManager (RIGHT_SHIFT → ClickGUI)
├── config/                   ← JSON config (gatau/config.json)
└── utils/                    ← DrawUtils, FontUtils, RenderUtils, ColorUtils, AnimationUtils, MathUtils
```

---

## Modules

### [RENDER] — 15 modules
| Module | Description |
|--------|-------------|
| Fullbright | Max gamma — never mine in the dark |
| ESP | Coloured boxes/outlines through walls |
| Tracers | Lines from crosshair to nearby players |
| NameTags | Improved name tags with health + distance |
| Item Physics | Tumbling dropped items |
| Motion Blur | Post-process blur on camera movement |
| Crosshair Editor | Custom crosshair styles (Default/Dot/Cross/Circle/Arrow) |
| Block Overlay | Custom block selection outline |
| CPS Counter | Left/right clicks per second HUD |
| FPS Counter | Frames per second HUD |
| Ping Display | Server latency HUD |
| Armor HUD | Equipped armor + durability |
| Potion HUD | Active potion effects + duration |
| Keystrokes | WASD + LMB/RMB on-screen display |
| HUD Editor | Drag-and-drop position editor for all HUD elements |

### [PLAYER] — 5 modules
| Module | Description |
|--------|-------------|
| Toggle Sprint | Auto-sprint without holding W+Ctrl |
| Auto Tool | Auto-switch to best tool per block |
| Fast Place | Remove block placement delay |
| Auto GG | Types "gg" at game end |
| Inventory Move | Walk while inventory is open |

### [WORLD] — 4 modules
| Module | Description |
|--------|-------------|
| Time Changer | Force client-side time of day |
| Clear Glass | Fully transparent glass blocks |
| Low Fire | Reduce on-fire overlay |
| No Weather | Remove rain/snow/thunder |

### [PERFORMANCE] — 6 modules
| Module | Description |
|--------|-------------|
| FPS Boost | Disable clouds/sky/weather for max FPS |
| Smart Culling | Frustum-cull off-screen entities |
| Entity Optimizer | Limit/reduce far entity updates |
| Particle Limiter | Cap particles, disable types |
| Chunk Optimizer | Limit chunk rebuilds per frame |
| Memory Optimizer | Periodic GC suggestions |

### [COSMETICS] — 2 modules
| Module | Description |
|--------|-------------|
| Cape System | Renders Gatau red / animated red cape |
| Cosmetic Manager | Master toggle, self/others cape visibility |

---

## GUI

### ClickGUI
- Open with **RIGHT_SHIFT**
- Drag panels by their header
- Right-click header to collapse/expand
- Left-click module to toggle
- Left-click module again to expand settings
- **Search bar** at the top — type to filter modules
- Red glow accents on enabled modules

### HUD Editor
- Open via the **HUD Editor** module toggle
- Drag any HUD element to reposition it
- Positions auto-save on close

### Main Menu
- Custom animated background with particles
- Singleplayer / Multiplayer / Alt Manager / Cosmetics / Settings / Exit

---

## Commands

All commands start with `.` (period):

| Command | Usage | Description |
|---------|-------|-------------|
| `.toggle` | `.toggle esp` | Toggle a module |
| `.bind` | `.bind esp HOME` | Bind a key to a module |
| `.list` | `.list` | List all modules and states |
| `.save` | `.save` | Save config to disk |
| `.help` | `.help` | Show all commands |

---

## Config

Config is saved to `gatau/config.json` (relative to the Minecraft run directory).  
Auto-loads on startup, auto-saves via `.save` command or when the HUD editor closes.

---

## Colors

| Token | Hex | Use |
|-------|-----|-----|
| Primary | `#FF3030` | Enabled modules, accents, logo |
| Background Dark | `#1A1A1A` | Panels |
| Background Medium | `#252525` | Hovered rows |
| Text White | `#FFFFFF` | Primary labels |
| Text Gray | `#AAAAAA` | Secondary labels |

---

## Notes

- This is a **client-side only** mod (`clientSideOnly = true`).
- Some modules (ClearGlass, ItemPhysics, Smart Culling) use ASM hooks; the hook
  points are documented in the source but the transformer is scaffolded — add your
  bytecode patches in `GatauTransformer` if needed.
- Cape textures are loaded from `assets/gatauc/textures/capes/` — place your
  64×32 PNG files there before building.
- The Alt Manager stores accounts **locally** in `gatau/alts.json` — no external
  services are used.
