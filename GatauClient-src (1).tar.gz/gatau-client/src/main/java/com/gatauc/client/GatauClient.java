package com.gatauc.client;

import com.gatauc.client.command.CommandManager;
import com.gatauc.client.config.ConfigManager;
import com.gatauc.client.core.GatauEventHooks;
import com.gatauc.client.event.EventBus;
import com.gatauc.client.gui.clickgui.ClickGUI;
import com.gatauc.client.gui.hud.HUDEditor;
import com.gatauc.client.gui.mainmenu.GatauMainMenu;
import com.gatauc.client.keybind.KeybindManager;
import com.gatauc.client.module.ModuleManager;
import com.gatauc.client.utils.Logger;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Gatau Client — Play Faster. Win Smarter.
 * Main mod class. Initializes all managers and systems.
 */
@Mod(
    modid = GatauClient.MODID,
    name = GatauClient.NAME,
    version = GatauClient.VERSION,
    clientSideOnly = true
)
public class GatauClient {

    public static final String MODID   = "gatauc";
    public static final String NAME    = "Gatau Client";
    public static final String VERSION = "1.0.0";
    public static final String SLOGAN  = "Play Faster. Win Smarter.";

    // Primary color: Red (#FF3030)
    public static final int COLOR_PRIMARY = 0xFF3030;
    public static final int COLOR_PRIMARY_ALPHA = 0xCCFF3030;

    /** Singleton instance */
    @Mod.Instance(MODID)
    public static GatauClient INSTANCE;

    // ── Managers ────────────────────────────────────────────────────────────
    private EventBus     eventBus;
    private ModuleManager moduleManager;
    private CommandManager commandManager;
    private KeybindManager keybindManager;
    private ConfigManager  configManager;
    private ClickGUI       clickGUI;
    private HUDEditor      hudEditor;

    // ── Lifecycle ────────────────────────────────────────────────────────────

    @EventHandler
    public void onInit(FMLInitializationEvent event) {
        Logger.info("Initializing " + NAME + " v" + VERSION + " — " + SLOGAN);

        // Boot order matters: event bus first, then modules, then config
        eventBus      = new EventBus();
        moduleManager = new ModuleManager();
        commandManager = new CommandManager();
        keybindManager = new KeybindManager();
        configManager  = new ConfigManager();

        // Build GUIs after modules are registered
        clickGUI  = new ClickGUI();
        hudEditor = new HUDEditor();

        // Register event hook bridge (Forge → Gatau event bus)
        new GatauEventHooks();

        // Register self for Forge events (main-menu injection)
        MinecraftForge.EVENT_BUS.register(this);

        Logger.info("All systems initialized successfully.");
    }

    @EventHandler
    public void onPostInit(FMLPostInitializationEvent event) {
        // Load saved config after everything is wired up
        configManager.load();
        Logger.info("Config loaded.");
    }

    /**
     * Replace the vanilla main menu with Gatau's custom one.
     */
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        if (event.gui != null
                && event.gui.getClass().getName().contains("GuiMainMenu")) {
            event.gui = new GatauMainMenu();
        }
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public static GatauClient getInstance() { return INSTANCE; }

    public EventBus      getEventBus()      { return eventBus; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public CommandManager getCommandManager() { return commandManager; }
    public KeybindManager getKeybindManager() { return keybindManager; }
    public ConfigManager  getConfigManager()  { return configManager; }
    public ClickGUI       getClickGUI()       { return clickGUI; }
    public HUDEditor      getHUDEditor()      { return hudEditor; }

    /** Shortcut to the Minecraft client instance. */
    public static Minecraft mc() { return Minecraft.getMinecraft(); }
}
