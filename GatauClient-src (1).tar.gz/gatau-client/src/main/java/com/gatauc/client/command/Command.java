package com.gatauc.client.command;

/**
 * Base class for all Gatau chat commands.
 *
 * Commands are invoked by typing a message that starts with "." (period).
 * Example: ".toggle esp"
 */
public abstract class Command {

    private final String name;
    private final String usage;
    private final String description;

    protected Command(String name, String usage, String description) {
        this.name        = name;
        this.usage       = usage;
        this.description = description;
    }

    /**
     * Execute the command.
     *
     * @param args tokens after the command name (split by space)
     */
    public abstract void execute(String[] args);

    public String getName()        { return name; }
    public String getUsage()       { return usage; }
    public String getDescription() { return description; }
}
