package com.gatauc.client.command;

import com.gatauc.client.command.impl.*;
import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventChat;
import com.gatauc.client.utils.ChatUtils;
import com.gatauc.client.utils.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Command Manager — registers commands and processes chat input.
 *
 * All commands start with a period: .toggle, .bind, .help, etc.
 */
public class CommandManager {

    private static final String PREFIX = ".";

    private final List<Command> commands = new ArrayList<>();

    public CommandManager() {
        register(new ToggleCommand());
        register(new BindCommand());
        register(new HelpCommand());
        register(new SaveCommand());
        register(new ListCommand());
    }

    private void register(Command command) {
        commands.add(command);
        Logger.debug("Registered command: " + PREFIX + command.getName());
    }

    @EventHandler
    public void onChat(EventChat event) {
        String message = event.getMessage();
        if (!message.startsWith(PREFIX)) return;

        // Cancel the message — don't send it to the server
        event.cancel();

        String[] parts = message.substring(PREFIX.length()).split(" ");
        if (parts.length == 0 || parts[0].isEmpty()) return;

        String commandName = parts[0].toLowerCase();
        String[] args      = new String[parts.length - 1];
        System.arraycopy(parts, 1, args, 0, args.length);

        for (Command cmd : commands) {
            if (cmd.getName().equalsIgnoreCase(commandName)) {
                try {
                    cmd.execute(args);
                } catch (Exception e) {
                    ChatUtils.sendMessage("&cError: " + e.getMessage());
                }
                return;
            }
        }

        ChatUtils.sendMessage("&cUnknown command. Type &f.help &cfor a list.");
    }

    public List<Command> getCommands() { return commands; }
}
