package com.gatauc.client.command.impl;

import com.gatauc.client.GatauClient;
import com.gatauc.client.command.Command;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.ChatUtils;
import org.lwjgl.input.Keyboard;

import java.util.Optional;

/**
 * .bind [module] [key] — sets a keybind for a module.
 * Example: .bind esp HOME
 */
public class BindCommand extends Command {

    public BindCommand() {
        super("bind", ".bind <module> <key>", "Binds a key to a module.");
    }

    @Override
    public void execute(String[] args) {
        if (args.length < 2) {
            ChatUtils.sendMessage("&cUsage: " + getUsage());
            return;
        }

        String keyName    = args[args.length - 1].toUpperCase();
        String moduleName = String.join(" ", args).replace(" " + args[args.length - 1], "");

        Optional<Module> opt = GatauClient.getInstance()
                .getModuleManager().getByName(moduleName);

        if (!opt.isPresent()) {
            ChatUtils.sendMessage("&cModule not found: &f" + moduleName);
            return;
        }

        int keyCode = Keyboard.getKeyIndex(keyName);
        if (keyCode == Keyboard.KEY_NONE) {
            ChatUtils.sendMessage("&cInvalid key: &f" + keyName);
            return;
        }

        opt.get().setKeyBind(keyCode);
        ChatUtils.sendMessage("&7" + opt.get().getName() + " &rbound to &f" + keyName);
    }
}
