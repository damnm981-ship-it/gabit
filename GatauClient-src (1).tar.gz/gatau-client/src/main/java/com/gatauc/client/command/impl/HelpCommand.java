package com.gatauc.client.command.impl;

import com.gatauc.client.GatauClient;
import com.gatauc.client.command.Command;
import com.gatauc.client.utils.ChatUtils;

/**
 * .help — lists all available commands.
 */
public class HelpCommand extends Command {

    public HelpCommand() {
        super("help", ".help", "Lists all available commands.");
    }

    @Override
    public void execute(String[] args) {
        ChatUtils.sendMessage("&c--- Gatau Client Commands ---");
        for (Command cmd : GatauClient.getInstance().getCommandManager().getCommands()) {
            ChatUtils.sendMessage("&f" + cmd.getUsage() + " &7— " + cmd.getDescription());
        }
    }
}
