package com.gatauc.client.command.impl;

import com.gatauc.client.GatauClient;
import com.gatauc.client.command.Command;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.ChatUtils;

/**
 * .list — prints every registered module and its current state.
 */
public class ListCommand extends Command {

    public ListCommand() {
        super("list", ".list", "Lists all modules and their state.");
    }

    @Override
    public void execute(String[] args) {
        ChatUtils.sendMessage("&c--- Modules ---");
        for (Module m : GatauClient.getInstance().getModuleManager().getModules()) {
            String state = m.isEnabled() ? "&aON" : "&cOFF";
            ChatUtils.sendMessage("&f" + m.getName() + " &7[" + m.getCategory().getDisplayName() + "] " + state);
        }
    }
}
