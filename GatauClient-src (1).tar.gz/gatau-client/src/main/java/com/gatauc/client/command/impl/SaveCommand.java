package com.gatauc.client.command.impl;

import com.gatauc.client.GatauClient;
import com.gatauc.client.command.Command;
import com.gatauc.client.utils.ChatUtils;

/**
 * .save — manually saves the current config.
 */
public class SaveCommand extends Command {

    public SaveCommand() {
        super("save", ".save", "Saves the current config to disk.");
    }

    @Override
    public void execute(String[] args) {
        GatauClient.getInstance().getConfigManager().save();
        ChatUtils.sendMessage("&aConfig saved successfully.");
    }
}
