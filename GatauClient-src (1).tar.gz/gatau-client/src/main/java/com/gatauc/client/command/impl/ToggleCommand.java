package com.gatauc.client.command.impl;

import com.gatauc.client.GatauClient;
import com.gatauc.client.command.Command;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.ChatUtils;

import java.util.Optional;

/**
 * .toggle [module] — enables or disables a module.
 */
public class ToggleCommand extends Command {

    public ToggleCommand() {
        super("toggle", ".toggle <module>", "Toggles a module on or off.");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            ChatUtils.sendMessage("&cUsage: " + getUsage());
            return;
        }

        String name = String.join(" ", args);
        Optional<Module> opt = GatauClient.getInstance()
                .getModuleManager().getByName(name);

        if (!opt.isPresent()) {
            ChatUtils.sendMessage("&cModule not found: &f" + name);
            return;
        }

        Module module = opt.get();
        module.toggle();
        ChatUtils.sendMessage("&7" + module.getName() + " &r→ " +
                (module.isEnabled() ? "&aEnabled" : "&cDisabled"));
    }
}
