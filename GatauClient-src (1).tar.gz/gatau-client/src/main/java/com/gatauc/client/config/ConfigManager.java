package com.gatauc.client.config;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.*;
import com.gatauc.client.utils.Logger;
import com.google.gson.*;

import java.io.*;
import java.nio.file.*;

/**
 * Config Manager — saves/loads module state and settings to a JSON file.
 *
 * Format:
 * {
 *   "modules": [
 *     { "name": "Fullbright", "enabled": true, "keybind": 0, "values": { "Strength": 1.0 } }
 *   ]
 * }
 */
public class ConfigManager {

    private static final String CONFIG_DIR  = "gatau";
    private static final String CONFIG_FILE = "config.json";

    private final Path configPath;
    private final Gson gson;

    public ConfigManager() {
        configPath = Paths.get(CONFIG_DIR, CONFIG_FILE);
        gson = new GsonBuilder().setPrettyPrinting().create();
    }

    // ── Save ─────────────────────────────────────────────────────────────────

    public void save() {
        try {
            Files.createDirectories(configPath.getParent());

            JsonObject root    = new JsonObject();
            JsonArray  modules = new JsonArray();

            for (Module module : GatauClient.getInstance().getModuleManager().getModules()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("name",    module.getName());
                obj.addProperty("enabled", module.isEnabled());
                obj.addProperty("keybind", module.getKeyBind());

                JsonObject vals = new JsonObject();
                for (Value<?> value : module.getValues()) {
                    if (value instanceof BooleanValue) {
                        vals.addProperty(value.getName(), ((BooleanValue) value).isEnabled());
                    } else if (value instanceof NumberValue) {
                        vals.addProperty(value.getName(), value.get().toString());
                    } else if (value instanceof ModeValue) {
                        vals.addProperty(value.getName(), (String) value.get());
                    }
                }
                obj.add("values", vals);
                modules.add(obj);
            }

            root.add("modules", modules);

            try (Writer w = Files.newBufferedWriter(configPath)) {
                gson.toJson(root, w);
            }

            Logger.info("Config saved to " + configPath);
        } catch (IOException e) {
            Logger.error("Failed to save config: " + e.getMessage());
        }
    }

    // ── Load ─────────────────────────────────────────────────────────────────

    public void load() {
        if (!Files.exists(configPath)) {
            Logger.info("No config file found — using defaults.");
            return;
        }

        try (Reader r = Files.newBufferedReader(configPath)) {
            JsonObject root    = gson.fromJson(r, JsonObject.class);
            JsonArray  modules = root.getAsJsonArray("modules");

            for (JsonElement el : modules) {
                JsonObject obj  = el.getAsJsonObject();
                String     name = obj.get("name").getAsString();

                GatauClient.getInstance().getModuleManager()
                        .getByName(name).ifPresent(module -> {
                    boolean enabled = obj.get("enabled").getAsBoolean();
                    int     keybind = obj.get("keybind").getAsInt();

                    module.setKeyBind(keybind);
                    if (enabled != module.isEnabled()) module.toggle();

                    if (obj.has("values")) {
                        JsonObject vals = obj.getAsJsonObject("values");
                        for (Value<?> value : module.getValues()) {
                            if (!vals.has(value.getName())) continue;
                            JsonElement ve = vals.get(value.getName());
                            if (value instanceof BooleanValue && ve.isJsonPrimitive()) {
                                ((BooleanValue) value).set(ve.getAsBoolean());
                            } else if (value instanceof NumberValue && ve.isJsonPrimitive()) {
                                ((NumberValue) value).set(ve.getAsDouble());
                            } else if (value instanceof ModeValue && ve.isJsonPrimitive()) {
                                value.set(ve.getAsString());
                            }
                        }
                    }
                });
            }

            Logger.info("Config loaded from " + configPath);
        } catch (Exception e) {
            Logger.error("Failed to load config: " + e.getMessage());
        }
    }
}
