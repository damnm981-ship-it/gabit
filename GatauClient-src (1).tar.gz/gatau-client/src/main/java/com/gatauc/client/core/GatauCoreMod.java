package com.gatauc.client.core;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import java.util.Map;

/**
 * Forge core mod entry point.
 *
 * Declared in the JAR manifest as {@code FMLCorePlugin} so Forge loads it
 * before the rest of the class files. This gives us an early hook for any
 * ASM transformations that modules require (ClearGlass, ItemPhysics, etc.).
 *
 * The actual mod class is {@link com.gatauc.client.GatauClient}.
 */
@IFMLLoadingPlugin.Name("GatauClientCore")
@IFMLLoadingPlugin.MCVersion("1.8.9")
@IFMLLoadingPlugin.SortingIndex(1001)
public class GatauCoreMod implements IFMLLoadingPlugin {

    @Override
    public String[] getASMTransformerClass() {
        // Return transformer class names here if ASM bytecode patching is needed.
        // For example: return new String[] { "com.gatauc.client.core.asm.GatauTransformer" };
        return new String[0];
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        // No data injection needed at core-mod level.
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}
