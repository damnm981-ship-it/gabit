package com.gatauc.client.core;

import com.gatauc.client.GatauClient;
import com.gatauc.client.event.events.*;
import com.gatauc.client.module.impl.render.CPSCounter;
import net.minecraft.network.Packet;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/**
 * Bridges Forge events into the Gatau event bus.
 *
 * This class registers itself on {@link MinecraftForge#EVENT_BUS} and
 * translates incoming Forge events to the appropriate Gatau {@link Event}
 * subclasses, then posts them via {@link com.gatauc.client.event.EventBus}.
 */
public class GatauEventHooks {

    public GatauEventHooks() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    // ── Render 2D (HUD) ──────────────────────────────────────────────────────

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        net.minecraft.client.gui.ScaledResolution sr = event.resolution;
        GatauClient.getInstance().getEventBus().post(
                new EventRender2D(event.partialTicks, sr.getScaledWidth(), sr.getScaledHeight()));
    }

    // ── Render 3D ────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        GatauClient.getInstance().getEventBus().post(
                new EventRender3D(event.partialTicks));
    }

    // ── Game tick (player update) ────────────────────────────────────────────

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            GatauClient.getInstance().getEventBus().post(new EventUpdate(EventUpdate.Stage.PRE));
        } else {
            GatauClient.getInstance().getEventBus().post(new EventUpdate(EventUpdate.Stage.POST));
        }
    }

    // ── Mouse clicks → CPS tracking ─────────────────────────────────────────

    @SubscribeEvent
    public void onMouseInput(InputEvent.MouseInputEvent event) {
        if (Mouse.getEventButtonState()) {
            int btn = Mouse.getEventButton();
            CPSCounter cps = GatauClient.getInstance().getModuleManager().get(CPSCounter.class);
            if (cps != null && cps.isEnabled()) {
                cps.registerClick(btn == 1);
            }
        }
    }
}
