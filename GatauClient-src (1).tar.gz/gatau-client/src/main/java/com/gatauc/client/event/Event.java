package com.gatauc.client.event;

/**
 * Base class for all Gatau Client events.
 *
 * Events are cancellable by default; subclasses that should never
 * be cancelled can override {@link #isCancellable()} to return false.
 */
public abstract class Event {

    private boolean cancelled = false;

    /** Whether this event can be cancelled by a listener. */
    public boolean isCancellable() { return true; }

    /** True if a listener has cancelled this event. */
    public boolean isCancelled()   { return cancelled; }

    /**
     * Cancel the event — subsequent listeners will not be called.
     * Has no effect on non-cancellable events.
     */
    public void cancel() {
        if (isCancellable()) cancelled = true;
    }
}
