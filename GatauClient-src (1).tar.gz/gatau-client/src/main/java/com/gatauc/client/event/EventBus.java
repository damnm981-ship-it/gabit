package com.gatauc.client.event;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Lightweight event bus.
 *
 * Usage:
 *   EventBus bus = GatauClient.getInstance().getEventBus();
 *   bus.register(this);       // registers all @EventHandler methods
 *   bus.unregister(this);
 *   bus.post(new EventRender(partialTicks));
 */
public class EventBus {

    /** Maps event class → list of registered listeners for that class */
    private final Map<Class<? extends Event>, List<ListenerMethod>> listeners = new HashMap<>();

    // ── Registration ────────────────────────────────────────────────────────

    /**
     * Scan the given object for methods annotated with {@link EventHandler}
     * and register them.
     */
    public void register(Object listener) {
        for (Method method : listener.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(EventHandler.class)) continue;
            if (method.getParameterCount() != 1)               continue;

            Class<?> paramType = method.getParameterTypes()[0];
            if (!Event.class.isAssignableFrom(paramType))      continue;

            @SuppressWarnings("unchecked")
            Class<? extends Event> eventClass = (Class<? extends Event>) paramType;

            method.setAccessible(true);
            listeners.computeIfAbsent(eventClass, k -> new ArrayList<>())
                     .add(new ListenerMethod(listener, method));
        }
    }

    /** Remove all handlers belonging to the given listener object. */
    public void unregister(Object listener) {
        for (List<ListenerMethod> list : listeners.values()) {
            list.removeIf(lm -> lm.instance == listener);
        }
    }

    // ── Posting ─────────────────────────────────────────────────────────────

    /**
     * Dispatch an event to all registered listeners.
     * Returns the (possibly cancelled) event so callers can check
     * {@link Event#isCancelled()}.
     */
    public <T extends Event> T post(T event) {
        List<ListenerMethod> list = listeners.get(event.getClass());
        if (list == null || list.isEmpty()) return event;

        for (ListenerMethod lm : new ArrayList<>(list)) {
            try {
                lm.method.invoke(lm.instance, event);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (event.isCancelled()) break;
        }
        return event;
    }

    // ── Inner type ───────────────────────────────────────────────────────────

    private static final class ListenerMethod {
        final Object instance;
        final Method method;

        ListenerMethod(Object instance, Method method) {
            this.instance = instance;
            this.method   = method;
        }
    }
}
