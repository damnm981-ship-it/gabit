package com.gatauc.client.event;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a method as an event handler on the Gatau event bus.
 *
 * The annotated method must accept exactly one parameter that is a
 * subclass of {@link Event}.
 *
 * Example:
 * <pre>{@code
 * @EventHandler
 * public void onRender(EventRender event) { ... }
 * }</pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler {
}
