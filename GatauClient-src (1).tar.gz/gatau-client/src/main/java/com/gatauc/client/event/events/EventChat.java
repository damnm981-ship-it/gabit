package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired when the player sends a chat message.
 * Cancelling prevents the message from being sent to the server.
 */
public class EventChat extends Event {

    private String message;

    public EventChat(String message) {
        this.message = message;
    }

    public String getMessage()             { return message; }
    public void   setMessage(String msg)   { this.message = msg; }
}
