package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired whenever a keyboard key is pressed.
 */
public class EventKey extends Event {

    private final int keyCode;

    public EventKey(int keyCode) {
        this.keyCode = keyCode;
    }

    public int getKeyCode() { return keyCode; }
}
