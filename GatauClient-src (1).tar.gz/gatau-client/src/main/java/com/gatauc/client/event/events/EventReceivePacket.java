package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;
import net.minecraft.network.Packet;

/**
 * Fired when a packet is received from the server.
 * Cancelling prevents the packet from being processed.
 */
public class EventReceivePacket extends Event {

    private final Packet<?> packet;

    public EventReceivePacket(Packet<?> packet) {
        this.packet = packet;
    }

    public Packet<?> getPacket() { return packet; }
}
