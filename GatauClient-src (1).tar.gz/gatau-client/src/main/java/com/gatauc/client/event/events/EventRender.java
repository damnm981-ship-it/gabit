package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired every render tick (client-side game loop).
 * partialTicks interpolates between the last two game ticks (0.0–1.0).
 */
public class EventRender extends Event {

    public enum Stage { PRE, POST }

    private final float partialTicks;
    private final Stage stage;

    public EventRender(float partialTicks, Stage stage) {
        this.partialTicks = partialTicks;
        this.stage        = stage;
    }

    public float getPartialTicks() { return partialTicks; }
    public Stage getStage()        { return stage; }

    @Override
    public boolean isCancellable() { return false; }
}
