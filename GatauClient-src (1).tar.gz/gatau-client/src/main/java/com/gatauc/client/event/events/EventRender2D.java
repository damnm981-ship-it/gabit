package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired during the 2-D HUD render phase (after the 3-D world is drawn).
 * Use this event for on-screen overlays, counters, and HUD elements.
 */
public class EventRender2D extends Event {

    private final float partialTicks;
    private final int   scaledWidth;
    private final int   scaledHeight;

    public EventRender2D(float partialTicks, int scaledWidth, int scaledHeight) {
        this.partialTicks  = partialTicks;
        this.scaledWidth   = scaledWidth;
        this.scaledHeight  = scaledHeight;
    }

    public float getPartialTicks() { return partialTicks; }
    public int   getScaledWidth()  { return scaledWidth; }
    public int   getScaledHeight() { return scaledHeight; }

    @Override
    public boolean isCancellable() { return false; }
}
