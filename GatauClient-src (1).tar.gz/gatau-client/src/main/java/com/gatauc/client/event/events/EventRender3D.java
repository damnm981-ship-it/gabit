package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired during the 3-D world render phase.
 * Use this for ESP, tracers, and other world-space overlays.
 */
public class EventRender3D extends Event {

    private final float partialTicks;

    public EventRender3D(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public float getPartialTicks() { return partialTicks; }

    @Override
    public boolean isCancellable() { return false; }
}
