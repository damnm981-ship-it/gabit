package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;
import net.minecraft.network.Packet;

/**
 * Fired when the client is about to send a packet to the server.
 * Cancelling drops the packet.
 */
public class EventSendPacket extends Event {

    private Packet<?> packet;

    public EventSendPacket(Packet<?> packet) {
        this.packet = packet;
    }

    public Packet<?> getPacket()           { return packet; }
    public void      setPacket(Packet<?> p){ this.packet = p; }
}
