package com.gatauc.client.event.events;

import com.gatauc.client.event.Event;

/**
 * Fired once per game tick (20 times/second) during the player update.
 */
public class EventUpdate extends Event {

    public enum Stage { PRE, POST }

    private final Stage stage;

    public EventUpdate(Stage stage) {
        this.stage = stage;
    }

    public Stage getStage() { return stage; }

    @Override
    public boolean isCancellable() { return false; }
}
