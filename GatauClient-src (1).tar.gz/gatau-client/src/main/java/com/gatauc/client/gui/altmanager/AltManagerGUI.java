package com.gatauc.client.gui.altmanager;

import com.gatauc.client.utils.ColorUtils;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;

import com.google.gson.*;
import net.minecraft.client.gui.*;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Alt Manager — store, switch, and manage Minecraft alt accounts locally.
 *
 * Accounts are stored in {@code gatau/alts.json}.
 * No external services — all local storage.
 */
public class AltManagerGUI extends GuiScreen {

    private static final String FILE = "gatau/alts.json";
    private static final Gson   GSON = new GsonBuilder().setPrettyPrinting().create();

    private final GuiScreen parent;
    private final List<AltEntry> alts = new ArrayList<>();

    // UI state
    private int    selectedIndex = -1;
    private String usernameInput = "";
    private boolean typingUsername = false;

    private static final int LIST_X  = 20;
    private static final int LIST_Y  = 50;
    private static final int ITEM_H  = 16;

    public AltManagerGUI(GuiScreen parent) {
        this.parent = parent;
        loadAlts();
    }

    // ── Alts I/O ────────────────────────────────────────────────────────────

    private void loadAlts() {
        alts.clear();
        try {
            Path p = Paths.get(FILE);
            if (!Files.exists(p)) return;
            JsonArray arr = GSON.fromJson(Files.newBufferedReader(p), JsonArray.class);
            for (JsonElement el : arr) {
                JsonObject obj = el.getAsJsonObject();
                alts.add(new AltEntry(obj.get("username").getAsString(),
                        obj.has("password") ? obj.get("password").getAsString() : ""));
            }
        } catch (Exception ignored) {}
    }

    private void saveAlts() {
        try {
            Files.createDirectories(Paths.get("gatau"));
            JsonArray arr = new JsonArray();
            for (AltEntry alt : alts) {
                JsonObject obj = new JsonObject();
                obj.addProperty("username", alt.username);
                obj.addProperty("password", alt.password);
                arr.add(obj);
            }
            try (Writer w = Files.newBufferedWriter(Paths.get(FILE))) {
                GSON.toJson(arr, w);
            }
        } catch (Exception ignored) {}
    }

    // ── GUI ─────────────────────────────────────────────────────────────────

    @Override
    public void initGui() {
        buttonList.clear();
        int bY = height - 30;
        buttonList.add(new GuiButton(1, 20,       bY, 80, 20, "Add"));
        buttonList.add(new GuiButton(2, 105,      bY, 80, 20, "Remove"));
        buttonList.add(new GuiButton(3, 190,      bY, 100, 20, "Use Alt"));
        buttonList.add(new GuiButton(4, width - 90, bY, 80, 20, "Back"));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        DrawUtils.drawRect(0, 0, width, height, 0xFF0D0D0D);

        // Title
        FontUtils.drawCenteredString("Alt Manager", width / 2, 10, ColorUtils.RED);
        FontUtils.drawCenteredString("Local accounts — no external services", width / 2, 22, 0xFF555555);

        // Columns header
        FontUtils.drawString("Username", LIST_X + 4, LIST_Y - 14, ColorUtils.TEXT_GRAY);
        DrawUtils.drawRect(LIST_X, LIST_Y - 2, width - LIST_X * 2, 1, 0xFF333333);

        // Alt list
        int iy = LIST_Y;
        for (int i = 0; i < alts.size(); i++) {
            AltEntry alt    = alts.get(i);
            boolean hov     = mouseX >= LIST_X && mouseX <= width - LIST_X
                    && mouseY >= iy && mouseY <= iy + ITEM_H;
            boolean sel     = selectedIndex == i;

            int bg = sel ? 0xBBFF3030 : (hov ? 0xBB2A2A2A : 0xBB1A1A1A);
            DrawUtils.drawRect(LIST_X, iy, width - LIST_X * 2, ITEM_H, bg);
            FontUtils.drawString(alt.username, LIST_X + 6, iy + 4, sel ? 0xFFFFFFFF : ColorUtils.TEXT_WHITE);
            iy += ITEM_H;
        }

        // Add account input bar
        if (typingUsername) {
            int ibY = height - 55;
            DrawUtils.drawRoundedRect(LIST_X, ibY, width - LIST_X * 2, 18, 4, 0xFF1E1E1E);
            DrawUtils.drawRect(LIST_X, ibY + 17, width - LIST_X * 2, 1, ColorUtils.RED);
            FontUtils.drawString(usernameInput + "|", LIST_X + 4, ibY + 5, ColorUtils.TEXT_WHITE);
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) throws java.io.IOException {
        // Select from list
        int iy = LIST_Y;
        for (int i = 0; i < alts.size(); i++) {
            if (mouseX >= LIST_X && mouseX <= width - LIST_X
                    && mouseY >= iy && mouseY <= iy + ITEM_H) {
                selectedIndex = i;
                break;
            }
            iy += ITEM_H;
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void keyTyped(char c, int keyCode) throws java.io.IOException {
        if (typingUsername) {
            if (keyCode == 28) { // ENTER
                if (!usernameInput.isEmpty()) {
                    alts.add(new AltEntry(usernameInput, ""));
                    saveAlts();
                    usernameInput = "";
                }
                typingUsername = false;
                return;
            }
            if (keyCode == 14) { // BACKSPACE
                if (!usernameInput.isEmpty())
                    usernameInput = usernameInput.substring(0, usernameInput.length() - 1);
                return;
            }
            if (c >= 32) usernameInput += c;
            return;
        }
        super.keyTyped(c, keyCode);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws java.io.IOException {
        switch (button.id) {
            case 1: // Add
                typingUsername = true;
                usernameInput  = "";
                break;
            case 2: // Remove
                if (selectedIndex >= 0 && selectedIndex < alts.size()) {
                    alts.remove(selectedIndex);
                    selectedIndex = -1;
                    saveAlts();
                }
                break;
            case 3: // Use Alt
                if (selectedIndex >= 0 && selectedIndex < alts.size()) {
                    AltEntry alt = alts.get(selectedIndex);
                    // Set offline-mode session (cracked / non-premium alt)
                    mc.getSession().getProfile().setId(java.util.UUID.nameUUIDFromBytes(
                            ("OfflinePlayer:" + alt.username).getBytes()));
                    // Note: proper Microsoft auth requires OAuth — not included here
                }
                break;
            case 4: // Back
                mc.displayGuiScreen(parent);
                break;
        }
    }

    // ── Data ─────────────────────────────────────────────────────────────────

    private static class AltEntry {
        String username;
        String password;

        AltEntry(String username, String password) {
            this.username = username;
            this.password = password;
        }
    }
}
