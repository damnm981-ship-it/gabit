package com.gatauc.client.gui.clickgui;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.*;
import com.gatauc.client.utils.AnimationUtils;
import com.gatauc.client.utils.ColorUtils;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * A draggable panel in the ClickGUI that lists modules for one {@link Category}.
 *
 * Features:
 *   • Drag by header to reposition
 *   • Click header to collapse/expand with smooth animation
 *   • Click module row to toggle
 *   • Sub-settings expand inline when the module is enabled
 *   • Red glow on enabled modules
 */
public class CategoryPanel {

    // ── Layout ────────────────────────────────────────────────────────────────
    private static final int HEADER_HEIGHT  = 18;
    private static final int MODULE_HEIGHT  = 14;
    private static final int VALUE_HEIGHT   = 12;
    private static final int PADDING        = 4;

    private final Category category;
    private int x, y;
    private final int width;

    private boolean collapsed    = false;
    private float   openAnim     = 1.0f; // 0 = collapsed, 1 = open

    // Drag state
    private boolean dragging     = false;
    private int     dragOffsetX, dragOffsetY;

    // Expanded module for settings
    private Module  expandedModule = null;

    public CategoryPanel(Category category, int x, int y, int width) {
        this.category = category;
        this.x        = x;
        this.y        = y;
        this.width    = width;
    }

    // ── Draw ─────────────────────────────────────────────────────────────────

    public void draw(int mouseX, int mouseY, String search) {
        // Smooth open/close animation
        openAnim = AnimationUtils.toggle(openAnim, !collapsed, 0.25f);

        List<Module> modules = getFilteredModules(search);
        int totalHeight = HEADER_HEIGHT + (int)((getContentHeight(modules)) * openAnim);

        // Panel background
        DrawUtils.drawRoundedRect(x, y, width, totalHeight, 6, ColorUtils.BG_DARK);

        // Header
        drawHeader(mouseX, mouseY);

        if (openAnim < 0.01f) return;

        // Module list
        int rowY = y + HEADER_HEIGHT;
        for (Module module : modules) {
            if (rowY > y + totalHeight - 2) break;
            rowY = drawModule(module, mouseX, mouseY, rowY, search);
        }
    }

    private void drawHeader(int mouseX, int mouseY) {
        // Header background with gradient from red to dark
        DrawUtils.drawGradientRect(x, y, width, HEADER_HEIGHT,
                0xFFFF3030, 0xFF1A1A1A);
        DrawUtils.drawRoundedRect(x, y, width, HEADER_HEIGHT, 6, 0x00000000); // just for rounded clip

        // Category name
        FontUtils.drawString(category.getDisplayName(), x + PADDING, y + 5, 0xFFFFFFFF);

        // Collapse arrow
        String arrow = collapsed ? "▶" : "▼";
        FontUtils.drawString(arrow, x + width - 12, y + 5, 0xFFCCCCCC);
    }

    private int drawModule(Module module, int mouseX, int mouseY, int rowY, String search) {
        boolean hovered = mouseX >= x && mouseX <= x + width
                && mouseY >= rowY && mouseY <= rowY + MODULE_HEIGHT;
        boolean enabled = module.isEnabled();

        // Row background
        int bg = hovered ? ColorUtils.BG_MEDIUM : ColorUtils.BG_DARK;
        DrawUtils.drawRect(x + 1, rowY, width - 2, MODULE_HEIGHT, bg);

        // Left accent bar if enabled
        if (enabled) {
            DrawUtils.drawRect(x + 1, rowY, 2, MODULE_HEIGHT, ColorUtils.RED);
        }

        // Module name
        int textColor = enabled ? ColorUtils.RED : ColorUtils.TEXT_GRAY;
        FontUtils.drawString(module.getName(), x + 8, rowY + 3, textColor);

        rowY += MODULE_HEIGHT;

        // Expanded settings
        if (module == expandedModule && enabled && !module.getValues().isEmpty()) {
            for (Value<?> value : module.getValues()) {
                rowY = drawValue(value, rowY);
            }
        }

        return rowY;
    }

    private int drawValue(Value<?> value, int rowY) {
        DrawUtils.drawRect(x + 2, rowY, width - 4, VALUE_HEIGHT, ColorUtils.BG_MEDIUM);

        if (value instanceof BooleanValue) {
            BooleanValue bv = (BooleanValue) value;
            String indicator = bv.isEnabled() ? "\u00a7aON" : "\u00a7cOFF";
            FontUtils.drawString(value.getName(), x + 10, rowY + 2, ColorUtils.TEXT_GRAY);
            FontUtils.drawRightAlignedString(indicator, x + width - 4, rowY + 2, ColorUtils.TEXT_WHITE);
        } else if (value instanceof NumberValue) {
            NumberValue nv = (NumberValue) value;
            FontUtils.drawString(value.getName(), x + 10, rowY + 2, ColorUtils.TEXT_GRAY);
            String val = String.format("%.1f", nv.get());
            FontUtils.drawRightAlignedString(val, x + width - 4, rowY + 2, ColorUtils.TEXT_WHITE);
            // Slider bar
            int barW = width - 20;
            float pct = (float)((nv.get() - nv.getMin()) / (nv.getMax() - nv.getMin()));
            DrawUtils.drawRect(x + 10, rowY + VALUE_HEIGHT - 2, barW, 2, ColorUtils.BG_LIGHT);
            DrawUtils.drawRect(x + 10, rowY + VALUE_HEIGHT - 2, (int)(barW * pct), 2, ColorUtils.RED);
        } else if (value instanceof ModeValue) {
            FontUtils.drawString(value.getName(), x + 10, rowY + 2, ColorUtils.TEXT_GRAY);
            FontUtils.drawRightAlignedString(value.get(), x + width - 4, rowY + 2, ColorUtils.TEXT_WHITE);
        }

        return rowY + VALUE_HEIGHT;
    }

    // ── Mouse interaction ────────────────────────────────────────────────────

    public void mouseClicked(int mouseX, int mouseY, int button) {
        // Header hit
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + HEADER_HEIGHT) {
            if (button == 0) {
                // Start drag
                dragging    = true;
                dragOffsetX = mouseX - x;
                dragOffsetY = mouseY - y;
            }
            if (button == 1) {
                // Right-click: toggle collapse
                collapsed = !collapsed;
            }
            return;
        }

        if (collapsed || openAnim < 0.1f) return;

        // Module rows
        List<Module> modules = getFilteredModules("");
        int rowY = y + HEADER_HEIGHT;
        for (Module module : modules) {
            if (mouseX >= x && mouseX <= x + width
                    && mouseY >= rowY && mouseY <= rowY + MODULE_HEIGHT) {
                if (button == 0) {
                    module.toggle();
                    expandedModule = (expandedModule == module) ? null : module;
                } else if (button == 1) {
                    expandedModule = (expandedModule == module) ? null : module;
                }
                return;
            }
            rowY += MODULE_HEIGHT;

            // Value clicks for expanded module
            if (module == expandedModule && module.isEnabled()) {
                for (Value<?> value : module.getValues()) {
                    if (mouseY >= rowY && mouseY <= rowY + VALUE_HEIGHT) {
                        handleValueClick(value, mouseX, button);
                        return;
                    }
                    rowY += VALUE_HEIGHT;
                }
            }
        }
    }

    private void handleValueClick(Value<?> value, int mouseX, int button) {
        if (value instanceof BooleanValue) {
            ((BooleanValue) value).toggle();
        } else if (value instanceof ModeValue) {
            ((ModeValue) value).cycle();
        } else if (value instanceof NumberValue) {
            NumberValue nv = (NumberValue) value;
            int barX   = x + 10;
            int barW   = width - 20;
            if (mouseX >= barX && mouseX <= barX + barW) {
                double pct = (double)(mouseX - barX) / barW;
                nv.set(nv.getMin() + pct * (nv.getMax() - nv.getMin()));
            }
        }
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
    }

    public void handleScroll(int scroll) {
        // Could be used to scroll a long list — not needed for the current panel count
    }

    // If dragging, update position — must be called each frame
    public void tick(int mouseX, int mouseY) {
        if (dragging) {
            x = mouseX - dragOffsetX;
            y = mouseY - dragOffsetY;
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private List<Module> getFilteredModules(String search) {
        List<Module> all = GatauClient.getInstance()
                .getModuleManager().getByCategory(category);
        if (search == null || search.isEmpty()) return all;

        List<Module> filtered = new ArrayList<>();
        for (Module m : all) {
            if (m.getName().toLowerCase().contains(search.toLowerCase())) {
                filtered.add(m);
            }
        }
        return filtered;
    }

    private int getContentHeight(List<Module> modules) {
        int h = 0;
        for (Module m : modules) {
            h += MODULE_HEIGHT;
            if (m == expandedModule && m.isEnabled()) {
                h += m.getValues().size() * VALUE_HEIGHT;
            }
        }
        return h + 2; // bottom padding
    }
}
