package com.gatauc.client.gui.clickgui;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Category;
import com.gatauc.client.utils.ColorUtils;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;

import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI — a smooth, animated, categorised module selector.
 *
 * Design:
 *   • Dark gray background with blur effect
 *   • One panel per category, draggable
 *   • Red (#FF3030) header accent with pulsing glow
 *   • Search bar at the top-centre
 *   • Rounded corners throughout
 *   • Smooth panel open/close animations
 *
 * Open with RIGHT_SHIFT (configured in KeybindManager).
 */
public class ClickGUI extends GuiScreen {

    private final List<CategoryPanel> panels = new ArrayList<>();
    private String searchQuery = "";

    // Layout constants
    private static final int PANEL_START_X = 10;
    private static final int PANEL_START_Y = 40;
    private static final int PANEL_GAP     = 5;
    private static final int PANEL_WIDTH   = 120;

    // Search bar
    private boolean searchFocused = false;

    public ClickGUI() {
        initPanels();
    }

    private void initPanels() {
        panels.clear();
        int x = PANEL_START_X;
        for (Category cat : Category.values()) {
            panels.add(new CategoryPanel(cat, x, PANEL_START_Y, PANEL_WIDTH));
            x += PANEL_WIDTH + PANEL_GAP;
        }
    }

    // ── GuiScreen lifecycle ───────────────────────────────────────────────────

    @Override
    public void initGui() {
        // Re-initialise panels so they pick up the correct screen size
        initPanels();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // ── Full-screen dark blur overlay ─────────────────────────────────
        DrawUtils.drawRect(0, 0, width, height, 0xBB0D0D0D);

        // ── Title bar ──────────────────────────────────────────────────────
        String title = "Gatau Client  v" + GatauClient.VERSION;
        int titleX = width / 2 - FontUtils.getStringWidth(title) / 2;
        FontUtils.drawString(title, titleX, 6, ColorUtils.pulsingRed());

        // ── Search bar ────────────────────────────────────────────────────
        int sbX = width / 2 - 75;
        int sbY = 18;
        int sbW = 150;
        int sbH = 14;
        int sbColor = searchFocused ? 0xFF2A2A2A : 0xFF1E1E1E;
        DrawUtils.drawRoundedRect(sbX, sbY, sbW, sbH, 4, sbColor);
        DrawUtils.drawRect(sbX, sbY + sbH - 1, sbW, 1, ColorUtils.RED_DIM);

        String searchDisplay = searchQuery.isEmpty() && !searchFocused
                ? "\u00a78Type to search..." : searchQuery + (searchFocused ? "|" : "");
        FontUtils.drawString(searchDisplay, sbX + 4, sbY + 3,
                searchQuery.isEmpty() ? 0xFF666666 : ColorUtils.TEXT_WHITE);

        // ── Category panels ───────────────────────────────────────────────
        for (CategoryPanel panel : panels) {
            panel.draw(mouseX, mouseY, searchQuery);
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        // Search bar focus
        int sbX = width / 2 - 75;
        int sbY = 18;
        searchFocused = mouseX >= sbX && mouseX <= sbX + 150 && mouseY >= sbY && mouseY <= sbY + 14;

        for (CategoryPanel panel : panels) {
            panel.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        for (CategoryPanel panel : panels) {
            panel.mouseReleased(mouseX, mouseY, state);
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int scroll = Mouse.getEventDWheel();
        if (scroll != 0) {
            for (CategoryPanel panel : panels) {
                panel.handleScroll(scroll);
            }
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            mc.displayGuiScreen(null);
            return;
        }

        if (searchFocused) {
            if (keyCode == Keyboard.KEY_BACK) {
                if (!searchQuery.isEmpty()) {
                    searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                }
            } else if (typedChar >= 32) {
                searchQuery += typedChar;
            }
            return;
        }

        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
