package com.gatauc.client.gui.hud;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.impl.render.*;
import com.gatauc.client.utils.ColorUtils;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;

import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * HUD Editor — drag-and-drop positioning of HUD elements.
 *
 * Each HUD module (FPSCounter, CPSCounter, PingDisplay, ArmorHUD, PotionHUD,
 * Keystrokes) exposes getHudX/getHudY/setHudX/setHudY. This screen renders
 * them all and lets the user drag them to any position.
 *
 * Opened via the HUDEditorModule module toggle.
 */
public class HUDEditor extends GuiScreen {

    /** A draggable reference to one HUD module's position. */
    private static class HUDElement {
        String  name;
        Module  module;
        int     x, y, w, h;
        boolean dragging;
        int     dragOX, dragOY;

        HUDElement(String name, Module module, int x, int y, int w, int h) {
            this.name   = name;
            this.module = module;
            this.x = x; this.y = y; this.w = w; this.h = h;
        }
    }

    private final List<HUDElement> elements = new ArrayList<>();
    private HUDElement selected = null;

    @Override
    public void initGui() {
        elements.clear();
        buildElements();
    }

    private void buildElements() {
        GatauClient gc = GatauClient.getInstance();

        FPSCounter fps = gc.getModuleManager().get(FPSCounter.class);
        if (fps != null) elements.add(new HUDElement("FPS Counter", fps, fps.getHudX(), fps.getHudY(), 60, 12));

        CPSCounter cps = gc.getModuleManager().get(CPSCounter.class);
        if (cps != null) elements.add(new HUDElement("CPS Counter", cps, cps.getHudX(), cps.getHudY(), 70, 12));

        PingDisplay ping = gc.getModuleManager().get(PingDisplay.class);
        if (ping != null) elements.add(new HUDElement("Ping Display", ping, ping.getHudX(), ping.getHudY(), 80, 12));

        ArmorHUD armor = gc.getModuleManager().get(ArmorHUD.class);
        if (armor != null) elements.add(new HUDElement("Armor HUD", armor, armor.getHudX(), armor.getHudY(), 50, 72));

        PotionHUD potion = gc.getModuleManager().get(PotionHUD.class);
        if (potion != null) elements.add(new HUDElement("Potion HUD", potion, potion.getHudX(), potion.getHudY(), 90, 50));

        Keystrokes ks = gc.getModuleManager().get(Keystrokes.class);
        if (ks != null) elements.add(new HUDElement("Keystrokes", ks, ks.getHudX(), ks.getHudY(), 48, 48));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // Update dragged element
        if (selected != null && selected.dragging) {
            selected.x = mouseX - selected.dragOX;
            selected.y = mouseY - selected.dragOY;
            applyPosition(selected);
        }

        // Dark semi-transparent overlay
        DrawUtils.drawRect(0, 0, width, height, 0xAA0D0D0D);

        // Title
        FontUtils.drawCenteredString("HUD Editor — drag elements to reposition",
                width / 2, 5, ColorUtils.TEXT_GRAY);
        FontUtils.drawCenteredString("ESC to close and save", width / 2, 15, 0xFF555555);

        // Draw all elements
        for (HUDElement el : elements) {
            boolean hovered = mouseX >= el.x && mouseX <= el.x + el.w
                    && mouseY >= el.y && mouseY <= el.y + el.h;
            int border = (el == selected) ? ColorUtils.RED : (hovered ? 0xFF666666 : 0xFF333333);

            DrawUtils.drawBorder(el.x, el.y, el.w, el.h, border, 0xAA1A1A1A);
            FontUtils.drawString(el.name, el.x + 2, el.y + 2, ColorUtils.TEXT_WHITE);
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        selected = null;
        for (HUDElement el : elements) {
            if (mouseX >= el.x && mouseX <= el.x + el.w
                    && mouseY >= el.y && mouseY <= el.y + el.h) {
                selected       = el;
                el.dragging    = true;
                el.dragOX      = mouseX - el.x;
                el.dragOY      = mouseY - el.y;
                break;
            }
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        for (HUDElement el : elements) {
            el.dragging = false;
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void onGuiClosed() {
        // Persist positions back into modules
        for (HUDElement el : elements) {
            applyPosition(el);
        }
        GatauClient.getInstance().getConfigManager().save();
    }

    private void applyPosition(HUDElement el) {
        Module m = el.module;
        if (m instanceof FPSCounter)   { ((FPSCounter)  m).setHudX(el.x); ((FPSCounter)  m).setHudY(el.y); }
        if (m instanceof CPSCounter)   { ((CPSCounter)  m).setHudX(el.x); ((CPSCounter)  m).setHudY(el.y); }
        if (m instanceof PingDisplay)  { ((PingDisplay) m).setHudX(el.x); ((PingDisplay) m).setHudY(el.y); }
        if (m instanceof ArmorHUD)     { ((ArmorHUD)    m).setHudX(el.x); ((ArmorHUD)    m).setHudY(el.y); }
        if (m instanceof PotionHUD)    { ((PotionHUD)   m).setHudX(el.x); ((PotionHUD)   m).setHudY(el.y); }
        if (m instanceof Keystrokes)   { ((Keystrokes)  m).setHudX(el.x); ((Keystrokes)  m).setHudY(el.y); }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
