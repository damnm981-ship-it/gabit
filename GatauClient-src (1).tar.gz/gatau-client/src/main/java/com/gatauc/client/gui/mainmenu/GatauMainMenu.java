package com.gatauc.client.gui.mainmenu;

import com.gatauc.client.GatauClient;
import com.gatauc.client.gui.altmanager.AltManagerGUI;
import com.gatauc.client.utils.AnimationUtils;
import com.gatauc.client.utils.ColorUtils;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import com.gatauc.client.utils.MathUtils;

import net.minecraft.client.gui.*;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom Gatau Client main menu.
 *
 * Layout:
 *   • Animated gradient background (slow colour shift)
 *   • Big "GATAU CLIENT" logo top-centre with red glow
 *   • Slogan subtitle
 *   • Buttons: Singleplayer | Multiplayer | Alt Manager | Cosmetics | Settings | Exit
 *   • Version watermark bottom-left
 *   • Animated particles in the background
 */
public class GatauMainMenu extends GuiScreen {

    // ── Animated background particles ────────────────────────────────────────

    private static final int PARTICLE_COUNT = 60;
    private final float[]  px  = new float[PARTICLE_COUNT];
    private final float[]  py  = new float[PARTICLE_COUNT];
    private final float[]  pvx = new float[PARTICLE_COUNT];
    private final float[]  pvy = new float[PARTICLE_COUNT];
    private final int[]    pc  = new int[PARTICLE_COUNT];

    // ── Button layout ────────────────────────────────────────────────────────

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int BTN_GAP = 4;

    // Button IDs
    private static final int ID_SINGLEPLAYER = 1;
    private static final int ID_MULTIPLAYER  = 2;
    private static final int ID_ALT_MANAGER  = 3;
    private static final int ID_COSMETICS    = 4;
    private static final int ID_SETTINGS     = 5;
    private static final int ID_EXIT         = 6;

    private long openTime;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void initGui() {
        openTime = System.currentTimeMillis();
        initParticles();

        int centerX = width / 2;
        int startY  = height / 2 - 10;

        buttonList.clear();
        buttonList.add(new GatauButton(ID_SINGLEPLAYER, centerX - BTN_W / 2,     startY,               BTN_W, BTN_H, "Singleplayer"));
        buttonList.add(new GatauButton(ID_MULTIPLAYER,  centerX - BTN_W / 2,     startY + BTN_H + BTN_GAP, BTN_W, BTN_H, "Multiplayer"));
        buttonList.add(new GatauButton(ID_ALT_MANAGER,  centerX - BTN_W / 2,     startY + (BTN_H + BTN_GAP) * 2, BTN_W, BTN_H, "Alt Manager"));
        buttonList.add(new GatauButton(ID_COSMETICS,    centerX - BTN_W / 2,     startY + (BTN_H + BTN_GAP) * 3, BTN_W, BTN_H, "Cosmetics"));
        buttonList.add(new GatauButton(ID_SETTINGS,     centerX - BTN_W / 2,     startY + (BTN_H + BTN_GAP) * 4, BTN_W, BTN_H, "Settings"));
        buttonList.add(new GatauButton(ID_EXIT,         centerX - BTN_W / 2,     startY + (BTN_H + BTN_GAP) * 5, BTN_W, BTN_H, "Exit"));
    }

    private void initParticles() {
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            px[i]  = (float)(Math.random() * 1920);
            py[i]  = (float)(Math.random() * 1080);
            pvx[i] = (float)(Math.random() * 0.4 - 0.2);
            pvy[i] = (float)(Math.random() * 0.4 - 0.2);
            pc[i]  = ColorUtils.withAlpha(ColorUtils.RED, 40 + (int)(Math.random() * 60));
        }
    }

    // ── Rendering ────────────────────────────────────────────────────────────

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // Background gradient (dark gray top to near-black bottom)
        DrawUtils.drawGradientRect(0, 0, width, height, 0xFF111111, 0xFF050505);

        // Animated particles
        updateAndDrawParticles();

        // Red horizontal accent line
        float elapsed = (System.currentTimeMillis() - openTime) / 1000.0f;
        int lineW = (int) Math.min(width, width * MathUtils.clamp(elapsed * 2f, 0f, 1f));
        DrawUtils.drawRect(0, height / 2 - 80, lineW, 1, ColorUtils.withAlpha(ColorUtils.RED, 80));

        // ── Logo ─────────────────────────────────────────────────────────
        int logoY = height / 2 - 110;
        drawLogo(logoY);

        // ── Slogan ───────────────────────────────────────────────────────
        String slogan = GatauClient.SLOGAN;
        FontUtils.drawCenteredString(slogan, width / 2, logoY + 28, ColorUtils.TEXT_GRAY);

        // ── Buttons ───────────────────────────────────────────────────────
        super.drawScreen(mouseX, mouseY, partialTicks);

        // ── Version watermark ────────────────────────────────────────────
        FontUtils.drawString("Gatau Client v" + GatauClient.VERSION, 3, height - 10, 0xFF444444);
        FontUtils.drawRightAlignedString("Minecraft 1.8.9 / Forge", width - 3, height - 10, 0xFF444444);
    }

    private void drawLogo(int y) {
        // Main title
        String title = "GATAU CLIENT";
        int tx = width / 2 - FontUtils.getStringWidth(title) * 2; // pseudo-scale
        // Draw shadow
        FontUtils.drawString(title, tx + 1, y + 1, 0xFF330000);
        // Draw red glow layers
        FontUtils.drawString(title, tx - 1, y,     ColorUtils.withAlpha(ColorUtils.RED, 100));
        FontUtils.drawString(title, tx + 1, y,     ColorUtils.withAlpha(ColorUtils.RED, 100));
        FontUtils.drawString(title, tx,     y - 1, ColorUtils.withAlpha(ColorUtils.RED, 100));
        FontUtils.drawString(title, tx,     y + 1, ColorUtils.withAlpha(ColorUtils.RED, 100));
        // Main text
        FontUtils.drawString(title, tx, y, ColorUtils.pulsingRed());
    }

    private void updateAndDrawParticles() {
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            px[i] += pvx[i];
            py[i] += pvy[i];

            // Wrap around edges
            if (px[i] < 0) px[i] = width;
            if (px[i] > width)  px[i] = 0;
            if (py[i] < 0) py[i] = height;
            if (py[i] > height) py[i] = 0;

            DrawUtils.drawFilledCircle((int) px[i], (int) py[i], 1.5f, pc[i]);
        }
    }

    // ── Button actions ───────────────────────────────────────────────────────

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case ID_SINGLEPLAYER:
                mc.displayGuiScreen(new GuiSelectWorld(this));
                break;
            case ID_MULTIPLAYER:
                mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            case ID_ALT_MANAGER:
                mc.displayGuiScreen(new AltManagerGUI(this));
                break;
            case ID_COSMETICS:
                // Open cosmetics screen (placeholder — uses ClickGUI filtered to COSMETICS)
                mc.displayGuiScreen(GatauClient.getInstance().getClickGUI());
                break;
            case ID_SETTINGS:
                mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings));
                break;
            case ID_EXIT:
                mc.shutdown();
                break;
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    // ── Inner helper ─────────────────────────────────────────────────────────

    /** A styled button matching the Gatau Client theme. */
    private static class GatauButton extends GuiButton {

        GatauButton(int id, int x, int y, int w, int h, String text) {
            super(id, x, y, w, h, text);
        }

        @Override
        public void drawButton(net.minecraft.client.Minecraft mc, int mouseX, int mouseY) {
            if (!this.visible) return;

            boolean hovered = mouseX >= xPosition && mouseX < xPosition + width
                    && mouseY >= yPosition && mouseY < yPosition + height;

            int bg = hovered ? 0xDDFF3030 : 0xBB1A1A1A;
            DrawUtils.drawRoundedRect(xPosition, yPosition, width, height, 4, bg);

            // Border
            int border = hovered ? 0xFFFF3030 : 0xFF333333;
            DrawUtils.drawRect(xPosition, yPosition, width, 1, border);
            DrawUtils.drawRect(xPosition, yPosition + height - 1, width, 1, border);

            // Text
            int textColor = hovered ? 0xFFFFFFFF : 0xFFAAAAAA;
            FontUtils.drawCenteredString(displayString, xPosition + width / 2, yPosition + (height - 8) / 2, textColor);
        }
    }
}
