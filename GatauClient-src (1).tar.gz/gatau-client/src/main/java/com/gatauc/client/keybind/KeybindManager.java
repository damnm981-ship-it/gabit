package com.gatauc.client.keybind;

import com.gatauc.client.GatauClient;
import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventKey;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

/**
 * Keybind Manager — listens for key presses via Forge and dispatches
 * {@link EventKey} events onto the Gatau event bus.
 *
 * Module toggle keys and the ClickGUI key are wired up here.
 */
public class KeybindManager {

    /** Default key to open the ClickGUI: RIGHT_SHIFT */
    private int clickGuiKey = Keyboard.KEY_RSHIFT;

    public KeybindManager() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        int key = Keyboard.getEventKey();
        if (!Keyboard.getEventKeyState()) return; // Only fire on key-down

        // Post to our own event bus so modules can listen
        GatauClient.getInstance().getEventBus().post(new EventKey(key));

        // Module keybinds
        GatauClient.getInstance().getModuleManager().onKeyPress(key);

        // ClickGUI toggle
        if (key == clickGuiKey) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.currentScreen == null) {
                mc.displayGuiScreen(GatauClient.getInstance().getClickGUI());
            } else {
                mc.displayGuiScreen(null);
            }
        }
    }

    public int  getClickGuiKey()        { return clickGuiKey; }
    public void setClickGuiKey(int key) { clickGuiKey = key; }
}
