package com.gatauc.client.module;

/**
 * Module categories shown as panels in the ClickGUI.
 */
public enum Category {

    RENDER      ("Render"),
    PLAYER      ("Player"),
    WORLD       ("World"),
    PERFORMANCE ("Performance"),
    COSMETICS   ("Cosmetics");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() { return displayName; }
}
