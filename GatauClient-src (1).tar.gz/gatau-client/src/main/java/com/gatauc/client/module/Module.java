package com.gatauc.client.module;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.value.Value;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every Gatau module.
 *
 * Subclasses register on the event bus when enabled and unregister when
 * disabled, so only active modules receive events.
 */
public abstract class Module {

    // ── Metadata ─────────────────────────────────────────────────────────────

    private final String   name;
    private final String   description;
    private final Category category;

    // ── State ────────────────────────────────────────────────────────────────

    private boolean enabled  = false;
    private int     keyBind  = Keyboard.KEY_NONE;

    // ── Values / Settings ────────────────────────────────────────────────────

    protected final List<Value<?>> values = new ArrayList<>();

    // ── Constructor ──────────────────────────────────────────────────────────

    protected Module(String name, String description, Category category) {
        this.name        = name;
        this.description = description;
        this.category    = category;
    }

    protected Module(String name, String description, Category category, int defaultKey) {
        this(name, description, category);
        this.keyBind = defaultKey;
    }

    // ── Lifecycle hooks ──────────────────────────────────────────────────────

    /** Called once when the module is first toggled on after startup. */
    public void onEnable()  {}

    /** Called once when the module is toggled off. */
    public void onDisable() {}

    // ── Toggle ───────────────────────────────────────────────────────────────

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) {
            GatauClient.getInstance().getEventBus().register(this);
            onEnable();
        } else {
            GatauClient.getInstance().getEventBus().unregister(this);
            onDisable();
        }
    }

    // ── Values ───────────────────────────────────────────────────────────────

    protected void addValue(Value<?> value) {
        values.add(value);
    }

    public List<Value<?>> getValues() { return values; }

    // ── Accessors ─────────────────────────────────────────────────────────────

    public String   getName()        { return name; }
    public String   getDescription() { return description; }
    public Category getCategory()    { return category; }
    public boolean  isEnabled()      { return enabled; }
    public int      getKeyBind()     { return keyBind; }
    public void     setKeyBind(int k){ keyBind = k; }
}
