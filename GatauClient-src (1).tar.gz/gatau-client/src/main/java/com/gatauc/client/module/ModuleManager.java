package com.gatauc.client.module;

import com.gatauc.client.module.impl.render.*;
import com.gatauc.client.module.impl.player.*;
import com.gatauc.client.module.impl.world.*;
import com.gatauc.client.module.impl.performance.*;
import com.gatauc.client.module.impl.cosmetics.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Holds every registered module and provides lookup helpers.
 */
public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        registerAll();
    }

    // ── Registration ─────────────────────────────────────────────────────────

    private void registerAll() {
        // RENDER
        register(new Fullbright());
        register(new ESP());
        register(new Tracers());
        register(new NameTags());
        register(new ItemPhysics());
        register(new MotionBlur());
        register(new CrosshairEditor());
        register(new BlockOverlay());
        register(new CPSCounter());
        register(new FPSCounter());
        register(new PingDisplay());
        register(new ArmorHUD());
        register(new PotionHUD());
        register(new Keystrokes());
        register(new HUDEditorModule());

        // PLAYER
        register(new ToggleSprint());
        register(new AutoTool());
        register(new FastPlace());
        register(new AutoGG());
        register(new InventoryMove());

        // WORLD
        register(new TimeChanger());
        register(new ClearGlass());
        register(new LowFire());
        register(new NoWeather());

        // PERFORMANCE
        register(new FPSBoost());
        register(new SmartCulling());
        register(new EntityOptimizer());
        register(new ParticleLimiter());
        register(new ChunkOptimizer());
        register(new MemoryOptimizer());

        // COSMETICS
        register(new CapeSystem());
        register(new CosmeticManager());
    }

    private void register(Module module) {
        modules.add(module);
    }

    // ── Lookup ────────────────────────────────────────────────────────────────

    public List<Module> getModules() { return modules; }

    public List<Module> getByCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }

    public Optional<Module> getByName(String name) {
        return modules.stream()
                      .filter(m -> m.getName().equalsIgnoreCase(name))
                      .findFirst();
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream()
                          .filter(m -> m.getClass() == clazz)
                          .findFirst()
                          .orElse(null);
    }

    /** Called from the Forge key-input hook; toggles bound modules. */
    public void onKeyPress(int keyCode) {
        for (Module m : modules) {
            if (m.getKeyBind() == keyCode) m.toggle();
        }
    }
}
