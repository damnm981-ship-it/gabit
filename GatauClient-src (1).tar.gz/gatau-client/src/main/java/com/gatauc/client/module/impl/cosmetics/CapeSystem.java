package com.gatauc.client.module.impl.cosmetics;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

/**
 * Cape System — renders a custom cape on the local player.
 * Supports static and animated capes stored in the mod's asset folder.
 */
public class CapeSystem extends Module {

    private final ModeValue capeType = new ModeValue("Cape", "Cape style",
            "Gatau Red", "Gatau Red", "Animated Red", "None");

    // Texture locations (assets/gatauc/textures/capes/)
    public static final ResourceLocation CAPE_RED      = new ResourceLocation("gatauc", "textures/capes/red_cape.png");
    public static final ResourceLocation CAPE_ANIMATED = new ResourceLocation("gatauc", "textures/capes/red_animated.png");

    public CapeSystem() {
        super("Cape System", "Shows a custom cape on your character.", Category.COSMETICS);
        addValue(capeType);
    }

    /**
     * Returns the ResourceLocation for the active cape, or null if disabled.
     * Called by the player renderer mixin.
     */
    public ResourceLocation getActiveCape() {
        if (!isEnabled()) return null;
        switch (capeType.get()) {
            case "Gatau Red":    return CAPE_RED;
            case "Animated Red": return CAPE_ANIMATED;
            default:             return null;
        }
    }
}
