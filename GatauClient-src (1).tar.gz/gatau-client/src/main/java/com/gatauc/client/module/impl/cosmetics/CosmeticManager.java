package com.gatauc.client.module.impl.cosmetics;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;

/**
 * Cosmetic Manager — master toggle for all local cosmetics.
 * Provides a single place to enable/disable the entire cosmetics system.
 */
public class CosmeticManager extends Module {

    private final BooleanValue showSelfCape = new BooleanValue("Show Own Cape",   "See your cape in F5 mode",   true);
    private final BooleanValue showOthersCape = new BooleanValue("Show Others' Capes", "See other clients' capes", true);

    public CosmeticManager() {
        super("Cosmetic Manager", "Controls all cosmetic features.", Category.COSMETICS);
        addValue(showSelfCape);
        addValue(showOthersCape);
    }

    public boolean shouldShowSelfCape()   { return isEnabled() && showSelfCape.isEnabled(); }
    public boolean shouldShowOthersCapes(){ return isEnabled() && showOthersCape.isEnabled(); }
}
