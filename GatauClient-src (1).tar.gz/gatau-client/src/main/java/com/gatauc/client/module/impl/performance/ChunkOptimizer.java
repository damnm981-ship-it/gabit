package com.gatauc.client.module.impl.performance;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;

/**
 * Chunk Optimizer — limits chunk updates per frame to prevent stuttering.
 * Works via ASM hook in RenderGlobal.
 */
public class ChunkOptimizer extends Module {

    private final NumberValue updatesPerFrame = new NumberValue("Updates/Frame", "Max chunk rebuilds per frame", 1, 1, 10, 1);

    public ChunkOptimizer() {
        super("Chunk Optimizer", "Limits chunk rebuilds per frame to reduce stutter.", Category.PERFORMANCE);
        addValue(updatesPerFrame);
    }

    public int getUpdatesPerFrame() { return (int) updatesPerFrame.get(); }
}
