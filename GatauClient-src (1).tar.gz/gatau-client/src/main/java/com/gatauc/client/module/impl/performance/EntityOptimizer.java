package com.gatauc.client.module.impl.performance;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;

import java.util.List;

/**
 * Entity Optimizer — reduces update frequency for far-away, non-essential entities.
 */
public class EntityOptimizer extends Module {

    private final NumberValue maxEntities = new NumberValue("Max Entities", "Max rendered entities", 50, 10, 200, 5);
    private final NumberValue range       = new NumberValue("Range",        "Cull range (blocks)",   32, 8,  64,  4);

    public EntityOptimizer() {
        super("Entity Optimizer", "Limits and optimises entity rendering.", Category.PERFORMANCE);
        addValue(maxEntities);
        addValue(range);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;

        int maxE = (int) maxEntities.get();
        double r = range.get();

        List<Entity> entities = mc.theWorld.loadedEntityList;
        int count = 0;

        for (Entity e : entities) {
            if (e instanceof EntityItem) {
                double dist = mc.thePlayer.getDistanceToEntity(e);
                if (dist > r) {
                    // Skip updates for far item entities (they still exist, just less costly)
                    e.ticksExisted = e.ticksExisted; // no-op; real impl via ASM
                }
                if (++count > maxE) break;
            }
        }
    }
}
