package com.gatauc.client.module.impl.performance;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;
import net.minecraft.client.Minecraft;

/**
 * FPS Boost — disables unnecessary render features to maximise frame rate.
 * Focused on Bedwars performance.
 */
public class FPSBoost extends Module {

    private final BooleanValue disableSky     = new BooleanValue("Disable Sky",     "Remove sky rendering",        true);
    private final BooleanValue disableClouds  = new BooleanValue("Disable Clouds",  "Remove cloud rendering",      true);
    private final BooleanValue disableWeather = new BooleanValue("Disable Weather", "Remove rain/snow particles",  true);
    private final BooleanValue disableVoid    = new BooleanValue("Disable Void Fog","Remove void fog",             true);

    // Saved render settings to restore on disable
    private int savedClouds;
    private boolean savedVoidFog;

    public FPSBoost() {
        super("FPS Boost", "Disables unneeded render features for max FPS.", Category.PERFORMANCE);
        addValue(disableSky);
        addValue(disableClouds);
        addValue(disableWeather);
        addValue(disableVoid);
    }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getMinecraft();
        savedClouds  = mc.gameSettings.clouds;
        if (disableClouds.isEnabled())  mc.gameSettings.clouds  = 0;
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getMinecraft();
        mc.gameSettings.clouds  = savedClouds;
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;

        if (disableWeather.isEnabled()) {
            mc.theWorld.setRainStrength(0.0f);
            mc.theWorld.setThunderStrength(0.0f);
        }
    }

    public boolean shouldDisableSky()    { return disableSky.isEnabled(); }
    public boolean shouldDisableVoidFog(){ return disableVoid.isEnabled(); }
}
