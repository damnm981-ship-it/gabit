package com.gatauc.client.module.impl.performance;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;

/**
 * Memory Optimizer — periodically triggers GC suggestions and clears
 * Minecraft's texture / resource caches to reduce memory pressure.
 */
public class MemoryOptimizer extends Module {

    private final NumberValue intervalSec = new NumberValue("Interval", "Seconds between GC hints", 30, 10, 120, 5);

    private long lastClean = 0L;
    private int  tickCount = 0;

    public MemoryOptimizer() {
        super("Memory Optimizer", "Periodically reduces memory usage.", Category.PERFORMANCE);
        addValue(intervalSec);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;

        tickCount++;
        long now = System.currentTimeMillis();
        long intervalMs = (long)(intervalSec.get() * 1000);

        if (now - lastClean > intervalMs) {
            lastClean = now;
            System.gc(); // suggest GC
        }
    }
}
