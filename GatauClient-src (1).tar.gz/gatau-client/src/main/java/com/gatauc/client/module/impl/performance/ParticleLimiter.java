package com.gatauc.client.module.impl.performance;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;
import com.gatauc.client.module.value.NumberValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/**
 * Particle Limiter — caps the number of active particles and optionally disables
 * specific particle types that cause big FPS drops.
 */
public class ParticleLimiter extends Module {

    private final NumberValue  maxParticles   = new NumberValue ("Max Particles",    "Max simultaneous particles", 50, 0, 500, 10);
    private final BooleanValue noExplosion    = new BooleanValue("No Explosions",    "Remove explosion particles", true);
    private final BooleanValue noCrit         = new BooleanValue("No Crits",         "Remove crit hit particles",  false);
    private final BooleanValue noBlockBreak   = new BooleanValue("No Block Break",   "Remove block-break debris",  false);

    private int savedParticles;

    public ParticleLimiter() {
        super("Particle Limiter", "Reduces particle count for better FPS.", Category.PERFORMANCE);
        addValue(maxParticles);
        addValue(noExplosion);
        addValue(noCrit);
        addValue(noBlockBreak);
    }

    @Override
    public void onEnable() {
        savedParticles = Minecraft.getMinecraft().gameSettings.particleSetting;
        Minecraft.getMinecraft().gameSettings.particleSetting = 2; // Minimal
    }

    @Override
    public void onDisable() {
        Minecraft.getMinecraft().gameSettings.particleSetting = savedParticles;
    }

    public boolean shouldBlockExplosion() { return noExplosion.isEnabled(); }
    public boolean shouldBlockCrit()      { return noCrit.isEnabled(); }
    public boolean shouldBlockBreak()     { return noBlockBreak.isEnabled(); }
    public int     getMax()               { return (int) maxParticles.get(); }
}
