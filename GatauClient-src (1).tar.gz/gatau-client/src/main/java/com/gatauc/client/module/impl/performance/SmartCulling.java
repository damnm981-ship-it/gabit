package com.gatauc.client.module.impl.performance;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;

/**
 * Smart Culling — aggressively culls entities and tiles that are outside the
 * player's view frustum. Works via ASM hook in EntityRenderDispatcher.
 */
public class SmartCulling extends Module {

    public SmartCulling() {
        super("Smart Culling", "Skips rendering entities outside the view frustum.", Category.PERFORMANCE);
    }
}
