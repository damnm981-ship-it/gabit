package com.gatauc.client.module.impl.player;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventReceivePacket;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.S02PacketChat;

/**
 * Auto GG — automatically types "gg" in chat when a game ends.
 * Detects game-over keywords in chat messages.
 */
public class AutoGG extends Module {

    private final ModeValue message = new ModeValue("Message", "Message to send",
            "gg", "gg", "GG", "gg wp", "GG WP", "good game");

    private long lastSent = 0L;
    private static final long COOLDOWN_MS = 3000L;

    public AutoGG() {
        super("Auto GG", "Sends 'gg' at the end of a game.", Category.PLAYER);
        addValue(message);
    }

    @EventHandler
    public void onReceivePacket(EventReceivePacket event) {
        if (!(event.getPacket() instanceof S02PacketChat)) return;

        S02PacketChat packet = (S02PacketChat) event.getPacket();
        String text = packet.getChatComponent().getUnformattedText().toLowerCase();

        boolean isGameEnd = text.contains("game over")
                || text.contains("winner")
                || text.contains("you won")
                || text.contains("victory")
                || text.contains("team wins");

        if (isGameEnd) {
            long now = System.currentTimeMillis();
            if (now - lastSent > COOLDOWN_MS) {
                lastSent = now;
                final String msg = message.get();
                // Delay slightly to feel natural
                new Thread(() -> {
                    try { Thread.sleep(600); } catch (InterruptedException ignored) {}
                    Minecraft.getMinecraft().thePlayer.sendChatMessage(msg);
                }).start();
            }
        }
    }
}
