package com.gatauc.client.module.impl.player;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MovingObjectPosition;

/**
 * Auto Tool — automatically switches to the best tool for the block being mined.
 */
public class AutoTool extends Module {

    private int previousSlot = -1;

    public AutoTool() {
        super("Auto Tool", "Switches to the best tool when mining a block.", Category.PLAYER);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        MovingObjectPosition mop = mc.objectMouseOver;
        if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
            // Restore previous slot when not mining
            if (previousSlot != -1 && !mc.gameSettings.keyBindAttack.isKeyDown()) {
                mc.thePlayer.inventory.currentItem = previousSlot;
                previousSlot = -1;
            }
            return;
        }

        if (!mc.gameSettings.keyBindAttack.isKeyDown()) return;

        Block block = mc.theWorld.getBlockState(mop.getBlockPos()).getBlock();
        int bestSlot = findBestTool(block, mc);

        if (bestSlot != -1 && bestSlot != mc.thePlayer.inventory.currentItem) {
            if (previousSlot == -1) {
                previousSlot = mc.thePlayer.inventory.currentItem;
            }
            mc.thePlayer.inventory.currentItem = bestSlot;
        }
    }

    private int findBestTool(Block block, Minecraft mc) {
        int best = -1;
        float bestSpeed = 1.0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (stack == null) continue;
            float speed = stack.getStrVsBlock(block);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        return best;
    }
}
