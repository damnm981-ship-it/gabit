package com.gatauc.client.module.impl.player;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;
import net.minecraft.client.Minecraft;

/**
 * Fast Place — removes the block-place delay so you can place blocks rapidly.
 */
public class FastPlace extends Module {

    private final NumberValue delay = new NumberValue("Delay", "Ticks between placements", 0, 0, 4, 1);

    public FastPlace() {
        super("Fast Place", "Removes the block placement cooldown.", Category.PLAYER);
        addValue(delay);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        // Override the right-click delay counter
        mc.rightClickDelayTimer = (int) delay.get();
    }
}
