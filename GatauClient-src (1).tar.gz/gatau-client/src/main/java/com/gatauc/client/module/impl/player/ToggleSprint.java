package com.gatauc.client.module.impl.player;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import net.minecraft.client.Minecraft;

/**
 * Toggle Sprint — keeps the player sprinting automatically without holding the
 * sprint key. Also adds an omni-directional sprint option.
 */
public class ToggleSprint extends Module {

    public ToggleSprint() {
        super("Toggle Sprint", "Auto-sprints so you don't hold the key.", Category.PLAYER);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        boolean moving = mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0;

        if (moving
                && !mc.thePlayer.isSprinting()
                && !mc.thePlayer.isCollidedHorizontally
                && mc.thePlayer.getFoodStats().getFoodLevel() > 6
                && !mc.thePlayer.isInWater()
                && !mc.thePlayer.isInLava()) {
            mc.thePlayer.setSprinting(true);
        }
    }
}
