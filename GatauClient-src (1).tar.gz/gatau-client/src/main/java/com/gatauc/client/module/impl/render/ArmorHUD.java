package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;

/**
 * Armor HUD — renders the player's equipped armor pieces with durability bars.
 */
public class ArmorHUD extends Module {

    private int hudX = 2;
    private int hudY = 60;

    public ArmorHUD() {
        super("Armor HUD", "Shows armor items and durability on the HUD.", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        ItemStack[] armor = mc.thePlayer.inventory.armorInventory;
        int y = hudY;

        // Draw from helmet (index 3) down to boots (index 0)
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = armor[i];
            if (stack == null) continue;

            // Item icon
            DrawUtils.drawItemStack(stack, hudX, y);

            // Durability text
            if (stack.isItemStackDamageable()) {
                int maxDmg = stack.getMaxDamage();
                int curDmg = maxDmg - stack.getItemDamage();
                int pct    = (curDmg * 100) / maxDmg;
                int col    = pct > 50 ? 0xFF44FF44 : (pct > 20 ? 0xFFFFAA00 : 0xFFFF3030);
                FontUtils.drawString(pct + "%", hudX + 18, y + 4, col);
            }
            y += 18;
        }
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
