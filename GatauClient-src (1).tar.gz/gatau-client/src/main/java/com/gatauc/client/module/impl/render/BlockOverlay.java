package com.gatauc.client.module.impl.render;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import com.gatauc.client.module.value.NumberValue;

/**
 * Block Overlay — changes the selection highlight on blocks.
 * The actual rendering is hooked in via ASM / EntityRenderer patch.
 */
public class BlockOverlay extends Module {

    private final ModeValue   style  = new ModeValue("Style",   "Outline style", "Default", "Default", "Filled", "None");
    private final NumberValue width  = new NumberValue("Width",  "Line width",    1.5, 0.5, 5.0, 0.5);

    public BlockOverlay() {
        super("Block Overlay", "Customises the block selection outline.", Category.RENDER);
        addValue(style);
        addValue(width);
    }

    public String  getStyle() { return style.get(); }
    public float   getWidth() { return (float) width.get(); }
}
