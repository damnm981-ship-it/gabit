package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.List;

/**
 * CPS Counter — tracks left/right clicks per second and displays them on the HUD.
 */
public class CPSCounter extends Module {

    private final BooleanValue showRight = new BooleanValue("Right Click", "Show right-click CPS", true);

    private final List<Long> leftClicks  = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();

    // HUD position (draggable via HUD editor)
    private int hudX = 2;
    private int hudY = 2;

    public CPSCounter() {
        super("CPS Counter", "Shows clicks per second on the HUD.", Category.RENDER);
        addValue(showRight);
    }

    /** Call this from the mouse-click hook. */
    public void registerClick(boolean right) {
        List<Long> list = right ? rightClicks : leftClicks;
        list.add(System.currentTimeMillis());
    }

    private int getCPS(List<Long> clicks) {
        long now = System.currentTimeMillis();
        clicks.removeIf(t -> now - t > 1000L);
        return clicks.size();
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        int lCps = getCPS(leftClicks);
        int rCps = getCPS(rightClicks);

        String text = "CPS  " + lCps + (showRight.isEnabled() ? " | " + rCps : "");

        // Background pill
        int w = FontUtils.getStringWidth(text) + 8;
        DrawUtils.drawRoundedRect(hudX, hudY, w, 12, 4, 0xAA1A1A1A);

        // Text
        FontUtils.drawString(text, hudX + 4, hudY + 2, 0xFFFF3030);
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
