package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;
import com.gatauc.client.module.value.ModeValue;
import com.gatauc.client.module.value.NumberValue;
import com.gatauc.client.utils.DrawUtils;
import net.minecraft.client.Minecraft;

/**
 * Crosshair Editor — replaces the vanilla crosshair with a customisable one.
 */
public class CrosshairEditor extends Module {

    private final ModeValue   style  = new ModeValue("Style", "Crosshair style",
            "Default", "Default", "Dot", "Cross", "Circle", "Arrow");
    private final NumberValue size   = new NumberValue("Size",      "Crosshair size",    6, 1, 20, 1);
    private final NumberValue thick  = new NumberValue("Thickness", "Line thickness",    1, 1, 5,  1);
    private final BooleanValue color = new BooleanValue("Red Color","Use client red",   true);

    public CrosshairEditor() {
        super("Crosshair Editor", "Customises the crosshair appearance.", Category.RENDER);
        addValue(style);
        addValue(size);
        addValue(thick);
        addValue(color);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        int cx = event.getScaledWidth()  / 2;
        int cy = event.getScaledHeight() / 2;
        int s  = (int) size.get();
        int t  = (int) thick.get();
        int c  = color.isEnabled() ? 0xFFFF3030 : 0xFFFFFFFF;

        switch (style.get()) {
            case "Default":
                DrawUtils.drawLine(cx - s, cy, cx + s, cy, t, c);
                DrawUtils.drawLine(cx, cy - s, cx, cy + s, t, c);
                break;
            case "Dot":
                DrawUtils.drawFilledCircle(cx, cy, t + 1, c);
                break;
            case "Cross":
                DrawUtils.drawLine(cx - s, cy - s, cx + s, cy + s, t, c);
                DrawUtils.drawLine(cx - s, cy + s, cx + s, cy - s, t, c);
                break;
            case "Circle":
                DrawUtils.drawCircle(cx, cy, s, t, c);
                break;
            case "Arrow":
                DrawUtils.drawArrow(cx, cy, s, c);
                break;
        }
    }
}
