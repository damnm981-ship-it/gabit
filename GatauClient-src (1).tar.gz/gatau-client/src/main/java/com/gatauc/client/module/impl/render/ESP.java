package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender3D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import com.gatauc.client.module.value.BooleanValue;
import com.gatauc.client.utils.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

/**
 * ESP — draws colored boxes or outlines around players through walls.
 */
public class ESP extends Module {

    private final ModeValue   mode    = new ModeValue("Mode", "ESP rendering mode", "Box", "Box", "Outline", "Glow");
    private final BooleanValue teamCheck = new BooleanValue("Team Check", "Don't highlight teammates", false);

    public ESP() {
        super("ESP", "Highlights players through walls.", Category.RENDER);
        addValue(mode);
        addValue(teamCheck);
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            if (entity == mc.thePlayer)            continue;

            int color = 0xFFFF3030; // Gatau red

            switch (mode.get()) {
                case "Box":
                    RenderUtils.drawEntityBox(entity, color, event.getPartialTicks());
                    break;
                case "Outline":
                    RenderUtils.drawEntityOutline(entity, color, event.getPartialTicks());
                    break;
                case "Glow":
                    RenderUtils.drawEntityGlow(entity, color, event.getPartialTicks());
                    break;
            }
        }
    }
}
