package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;

/**
 * FPS Counter — displays current frames-per-second on the HUD.
 */
public class FPSCounter extends Module {

    private int hudX = 2;
    private int hudY = 16;

    public FPSCounter() {
        super("FPS Counter", "Shows frames per second on the HUD.", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        int fps  = Minecraft.getDebugFPS();
        String text = "FPS  " + fps;

        int w = FontUtils.getStringWidth(text) + 8;
        DrawUtils.drawRoundedRect(hudX, hudY, w, 12, 4, 0xAA1A1A1A);
        FontUtils.drawString(text, hudX + 4, hudY + 2, 0xFFFF3030);
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
