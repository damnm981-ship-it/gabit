package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import net.minecraft.client.Minecraft;

/**
 * Fullbright — sets gamma to maximum so the world is always fully lit.
 */
public class Fullbright extends Module {

    private float savedGamma;

    public Fullbright() {
        super("Fullbright", "Makes the game always fully bright.", Category.RENDER);
    }

    @Override
    public void onEnable() {
        savedGamma = Minecraft.getMinecraft().gameSettings.gammaSetting;
        Minecraft.getMinecraft().gameSettings.gammaSetting = 1000.0f;
    }

    @Override
    public void onDisable() {
        Minecraft.getMinecraft().gameSettings.gammaSetting = savedGamma;
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        // Ensure gamma stays at max while enabled (some mods reset it)
        if (event.getStage() == EventUpdate.Stage.PRE) {
            Minecraft.getMinecraft().gameSettings.gammaSetting = 1000.0f;
        }
    }
}
