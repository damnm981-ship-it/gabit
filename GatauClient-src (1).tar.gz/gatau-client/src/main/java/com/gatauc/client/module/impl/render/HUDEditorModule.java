package com.gatauc.client.module.impl.render;

import com.gatauc.client.GatauClient;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

/**
 * HUD Editor — opens the drag-and-drop HUD editor when toggled.
 */
public class HUDEditorModule extends Module {

    public HUDEditorModule() {
        super("HUD Editor", "Opens the drag-and-drop HUD editor.", Category.RENDER, Keyboard.KEY_NONE);
    }

    @Override
    public void onEnable() {
        Minecraft.getMinecraft().displayGuiScreen(GatauClient.getInstance().getHUDEditor());
        // Immediately set back to disabled so toggling works next time
        setEnabled(false);
    }
}
