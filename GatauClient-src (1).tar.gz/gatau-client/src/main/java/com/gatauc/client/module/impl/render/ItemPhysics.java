package com.gatauc.client.module.impl.render;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;

/**
 * Item Physics — makes dropped items rotate and tumble realistically.
 *
 * This module works via a mixin / ASM hook in EntityItemRenderer.
 * The flag {@link #isEnabled()} is checked by the renderer hook.
 */
public class ItemPhysics extends Module {

    public ItemPhysics() {
        super("Item Physics", "Makes dropped items tumble realistically.", Category.RENDER);
    }
}
