package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/**
 * Keystrokes — renders a WASD + LMB/RMB keystroke display on the HUD.
 */
public class Keystrokes extends Module {

    private int hudX = 4;
    private int hudY = 200;

    public Keystrokes() {
        super("Keystrokes", "Shows WASD and mouse buttons on-screen.", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        GameSettings ks = mc.gameSettings;

        boolean w   = Keyboard.isKeyDown(ks.keyBindForward.getKeyCode());
        boolean s   = Keyboard.isKeyDown(ks.keyBindBack.getKeyCode());
        boolean a   = Keyboard.isKeyDown(ks.keyBindLeft.getKeyCode());
        boolean d   = Keyboard.isKeyDown(ks.keyBindRight.getKeyCode());
        boolean lmb = Mouse.isButtonDown(0);
        boolean rmb = Mouse.isButtonDown(1);

        int keyW = 14;
        int keyH = 14;
        int gap  = 2;

        // Row 1: W (centered)
        drawKey("W", hudX + keyW + gap, hudY, keyW, keyH, w);
        // Row 2: A S D
        drawKey("A", hudX,                  hudY + keyH + gap, keyW, keyH, a);
        drawKey("S", hudX + keyW + gap,     hudY + keyH + gap, keyW, keyH, s);
        drawKey("D", hudX + (keyW + gap)*2, hudY + keyH + gap, keyW, keyH, d);
        // Row 3: LMB RMB
        int rowY = hudY + (keyH + gap) * 2;
        drawKey("L", hudX,             rowY, keyW, keyH, lmb);
        drawKey("R", hudX + keyW + gap + (keyW + gap), rowY, keyW, keyH, rmb);
    }

    private void drawKey(String label, int x, int y, int w, int h, boolean pressed) {
        int bg   = pressed ? 0xAAFF3030 : 0xAA1A1A1A;
        int text = pressed ? 0xFFFFFFFF : 0xFFAAAAAA;
        DrawUtils.drawRoundedRect(x, y, w, h, 3, bg);
        FontUtils.drawCenteredString(label, x + w / 2, y + h / 2 - 3, text);
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
