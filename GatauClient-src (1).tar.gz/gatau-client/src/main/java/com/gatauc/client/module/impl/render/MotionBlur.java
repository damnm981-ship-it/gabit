package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.util.ResourceLocation;

/**
 * Motion Blur — applies a configurable motion-blur post-processing effect.
 */
public class MotionBlur extends Module {

    private final NumberValue strength = new NumberValue("Strength", "Blur strength (0–1)", 0.5, 0.1, 0.9, 0.05);

    private static final ResourceLocation BLUR_SHADER =
            new ResourceLocation("shaders/post/blur.json");

    public MotionBlur() {
        super("Motion Blur", "Applies a motion-blur effect to camera movement.", Category.RENDER);
        addValue(strength);
    }

    @Override
    public void onEnable() {
        applyShader();
    }

    @Override
    public void onDisable() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.entityRenderer != null) {
                mc.entityRenderer.stopUseShader();
            }
        } catch (Exception ignored) {}
    }

    @EventHandler
    public void onRender(EventRender event) {
        // Strength can be adjusted at runtime
    }

    private void applyShader() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            mc.entityRenderer.loadShader(BLUR_SHADER);
        } catch (Exception ignored) {}
    }
}
