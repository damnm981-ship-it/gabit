package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender3D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.BooleanValue;
import com.gatauc.client.module.value.NumberValue;
import com.gatauc.client.utils.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

/**
 * NameTags — renders larger, clearer name tags above players.
 * Shows name, health, and optionally distance.
 */
public class NameTags extends Module {

    private final BooleanValue showHealth   = new BooleanValue("Health",   "Show health bar",    true);
    private final BooleanValue showDistance = new BooleanValue("Distance", "Show distance in m", true);
    private final NumberValue  scale        = new NumberValue ("Scale",    "Tag scale", 1.5, 0.5, 4.0, 0.1);

    public NameTags() {
        super("NameTags", "Renders improved name tags on players.", Category.RENDER);
        addValue(showHealth);
        addValue(showDistance);
        addValue(scale);
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            if (entity == mc.thePlayer)            continue;

            EntityPlayer player = (EntityPlayer) entity;
            RenderUtils.drawNameTag(player,
                    showHealth.isEnabled(),
                    showDistance.isEnabled(),
                    (float) scale.get(),
                    event.getPartialTicks());
        }
    }
}
