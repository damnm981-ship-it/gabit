package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;

/**
 * Ping Display — shows the player's current server ping on the HUD.
 */
public class PingDisplay extends Module {

    private int hudX = 2;
    private int hudY = 30;

    public PingDisplay() {
        super("Ping Display", "Shows your server ping on the HUD.", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        int ping = getPing();
        String text = "Ping  " + ping + "ms";

        // Color red if > 150 ms, green if < 50 ms, otherwise white
        int color = ping > 150 ? 0xFFFF4444 : (ping < 50 ? 0xFF44FF44 : 0xFFFFFFFF);

        int w = FontUtils.getStringWidth(text) + 8;
        DrawUtils.drawRoundedRect(hudX, hudY, w, 12, 4, 0xAA1A1A1A);
        FontUtils.drawString(text, hudX + 4, hudY + 2, color);
    }

    private int getPing() {
        try {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null) return 0;
            NetHandlerPlayClient handler = mc.getNetHandler();
            if (handler == null)       return 0;
            NetworkPlayerInfo info = handler.getPlayerInfo(mc.thePlayer.getUniqueID());
            return info != null ? info.getResponseTime() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
