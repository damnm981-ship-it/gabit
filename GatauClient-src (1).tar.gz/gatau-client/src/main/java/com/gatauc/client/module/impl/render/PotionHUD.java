package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender2D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.utils.DrawUtils;
import com.gatauc.client.utils.FontUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.PotionEffect;

import java.util.Collection;

/**
 * Potion HUD — shows active potion effects with remaining time.
 */
public class PotionHUD extends Module {

    private int hudX = 2;
    private int hudY = 140;

    public PotionHUD() {
        super("Potion HUD", "Shows active potion effects and durations.", Category.RENDER);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;

        Collection<PotionEffect> effects = mc.thePlayer.getActivePotionEffects();
        if (effects.isEmpty()) return;

        int y = hudY;
        for (PotionEffect effect : effects) {
            String name = net.minecraft.potion.Potion.potionTypes[effect.getPotionID()].getName();
            // Trim "potion." prefix
            if (name.startsWith("potion.")) name = name.substring(7);
            name = capitalise(name);

            int secs = effect.getDuration() / 20;
            String dur = String.format("%d:%02d", secs / 60, secs % 60);
            String line = name + "  " + dur;

            int w = FontUtils.getStringWidth(line) + 8;
            DrawUtils.drawRoundedRect(hudX, y, w, 12, 4, 0xAA1A1A1A);
            FontUtils.drawString(line, hudX + 4, y + 2, 0xFFFF3030);
            y += 14;
        }
    }

    private String capitalise(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public int getHudX()       { return hudX; }
    public int getHudY()       { return hudY; }
    public void setHudX(int x) { this.hudX = x; }
    public void setHudY(int y) { this.hudY = y; }
}
