package com.gatauc.client.module.impl.render;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventRender3D;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import com.gatauc.client.utils.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

/**
 * Tracers — draws lines from the player's crosshair to nearby entities.
 */
public class Tracers extends Module {

    private final ModeValue origin = new ModeValue("Origin", "Where the line starts",
            "Crosshair", "Feet", "Top");

    public Tracers() {
        super("Tracers", "Draws lines to nearby players.", Category.RENDER);
        addValue(origin);
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;

        GL11.glPushMatrix();
        GL11.glLineWidth(1.5f);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            if (entity == mc.thePlayer)            continue;

            RenderUtils.drawTracer(entity, 0xCCFF3030, origin.get(), event.getPartialTicks());
        }

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }
}
