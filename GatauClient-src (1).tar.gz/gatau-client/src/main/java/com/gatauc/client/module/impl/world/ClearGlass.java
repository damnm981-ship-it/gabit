package com.gatauc.client.module.impl.world;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;

/**
 * Clear Glass — makes glass fully transparent by removing its texture overlay.
 * Works via ASM hook in BlockGlass renderer.
 * The flag {@link #isEnabled()} is checked by the render hook.
 */
public class ClearGlass extends Module {

    public ClearGlass() {
        super("Clear Glass", "Makes all glass blocks fully transparent.", Category.WORLD);
    }
}
