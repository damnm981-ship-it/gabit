package com.gatauc.client.module.impl.world;

import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.NumberValue;

/**
 * Low Fire — reduces the fire overlay height so you can see through it.
 * Works via a resource-pack-style texture replacement at runtime.
 */
public class LowFire extends Module {

    private final NumberValue height = new NumberValue("Height", "Fire overlay scale (0 = invisible)", 0.2, 0.0, 1.0, 0.05);

    public LowFire() {
        super("Low Fire", "Reduces the on-fire screen overlay.", Category.WORLD);
        addValue(height);
    }

    public float getHeight() { return (float) height.get(); }
}
