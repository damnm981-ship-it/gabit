package com.gatauc.client.module.impl.world;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import net.minecraft.client.Minecraft;

/**
 * No Weather — permanently clears rain and thunder on the client side.
 */
public class NoWeather extends Module {

    public NoWeather() {
        super("No Weather", "Removes rain and thunder effects client-side.", Category.WORLD);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;
        mc.theWorld.setRainStrength(0.0f);
        mc.theWorld.setThunderStrength(0.0f);
    }
}
