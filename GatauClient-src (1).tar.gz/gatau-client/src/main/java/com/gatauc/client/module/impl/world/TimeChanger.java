package com.gatauc.client.module.impl.world;

import com.gatauc.client.event.EventHandler;
import com.gatauc.client.event.events.EventUpdate;
import com.gatauc.client.module.Category;
import com.gatauc.client.module.Module;
import com.gatauc.client.module.value.ModeValue;
import net.minecraft.client.Minecraft;

/**
 * Time Changer — overrides the client-side time so the world always appears
 * to be at a chosen time-of-day.
 */
public class TimeChanger extends Module {

    private final ModeValue time = new ModeValue("Time", "Time of day",
            "Day", "Day", "Noon", "Sunset", "Night", "Midnight");

    public TimeChanger() {
        super("Time Changer", "Forces a specific client-side time of day.", Category.WORLD);
        addValue(time);
    }

    @EventHandler
    public void onUpdate(EventUpdate event) {
        if (event.getStage() != EventUpdate.Stage.PRE) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) return;

        long ticks;
        switch (time.get()) {
            case "Noon":     ticks = 6000;  break;
            case "Sunset":   ticks = 12000; break;
            case "Night":    ticks = 14000; break;
            case "Midnight": ticks = 18000; break;
            default:         ticks = 1000;  break; // Day
        }
        mc.theWorld.setWorldTime(ticks);
    }
}
