package com.gatauc.client.module.value;

/** A true/false toggle setting. */
public class BooleanValue extends Value<Boolean> {

    public BooleanValue(String name, String description, boolean defaultValue) {
        super(name, description, defaultValue);
    }

    public boolean isEnabled() { return value; }

    public void toggle() { value = !value; }
}
