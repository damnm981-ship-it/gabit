package com.gatauc.client.module.value;

/** A cycling-option setting (e.g., "Normal / Fast / Instant"). */
public class ModeValue extends Value<String> {

    private final String[] modes;
    private int currentIndex;

    public ModeValue(String name, String description, String... modes) {
        super(name, description, modes[0]);
        this.modes        = modes;
        this.currentIndex = 0;
    }

    public ModeValue(String name, String description, int defaultIndex, String... modes) {
        super(name, description, modes[defaultIndex]);
        this.modes        = modes;
        this.currentIndex = defaultIndex;
    }

    /** Advance to the next mode, wrapping around. */
    public void cycle() {
        currentIndex = (currentIndex + 1) % modes.length;
        value        = modes[currentIndex];
    }

    public String[] getModes()       { return modes; }
    public int      getCurrentIndex(){ return currentIndex; }

    public boolean is(String mode) {
        return value.equalsIgnoreCase(mode);
    }
}
