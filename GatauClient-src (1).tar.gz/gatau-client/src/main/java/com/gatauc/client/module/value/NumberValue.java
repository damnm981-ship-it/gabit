package com.gatauc.client.module.value;

/** A numeric slider setting with min/max bounds. */
public class NumberValue extends Value<Double> {

    private final double min;
    private final double max;
    private final double increment;

    public NumberValue(String name, String description,
                       double defaultValue, double min, double max, double increment) {
        super(name, description, defaultValue);
        this.min       = min;
        this.max       = max;
        this.increment = increment;
    }

    @Override
    public void set(Double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public double getMin()       { return min; }
    public double getMax()       { return max; }
    public double getIncrement() { return increment; }

    /** Returns the value rounded to the nearest increment step. */
    public double getSnapped() {
        return Math.round(value / increment) * increment;
    }
}
