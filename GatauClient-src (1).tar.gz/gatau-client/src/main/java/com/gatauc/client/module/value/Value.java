package com.gatauc.client.module.value;

/**
 * A typed setting that belongs to a module.
 *
 * @param <T> the value type (Boolean, Double, String, …)
 */
public abstract class Value<T> {

    private final String name;
    private final String description;
    protected T value;

    protected Value(String name, String description, T defaultValue) {
        this.name        = name;
        this.description = description;
        this.value       = defaultValue;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public T      get()            { return value; }
    public void   set(T value)     { this.value = value; }
}
