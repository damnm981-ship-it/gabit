package com.gatauc.client.utils;

/**
 * Smooth animation helpers used in the ClickGUI and HUD Editor.
 *
 * These are simple linear interpolations — not physically-based springs —
 * but they produce a fast, clean "slide" feel suitable for a PvP client GUI.
 */
public class AnimationUtils {

    /**
     * Returns a value that moves toward {@code target} at the given speed.
     * Call each render frame with the previous {@code current} value.
     *
     * @param current  last frame's value
     * @param target   where you want to end up
     * @param speed    fraction of remaining distance to close per frame (0–1)
     */
    public static float animate(float current, float target, float speed) {
        return current + (target - current) * MathUtils.clamp(speed, 0.0f, 1.0f);
    }

    /**
     * Animates toward 1.0 when {@code condition} is true, toward 0.0 when false.
     * Useful for toggle transitions in the ClickGUI.
     */
    public static float toggle(float current, boolean condition, float speed) {
        return animate(current, condition ? 1.0f : 0.0f, speed);
    }

    /**
     * Returns an eased progress (0..1) over a given duration.
     *
     * @param startTime  System.currentTimeMillis() when the animation started
     * @param durationMs total animation duration in milliseconds
     */
    public static float progress(long startTime, long durationMs) {
        float t = (System.currentTimeMillis() - startTime) / (float) durationMs;
        return MathUtils.easeInOut(MathUtils.clamp(t, 0.0f, 1.0f));
    }
}
