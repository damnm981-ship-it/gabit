package com.gatauc.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

/**
 * Utility for sending formatted messages into the client chat.
 */
public class ChatUtils {

    private static final String PREFIX =
            EnumChatFormatting.DARK_GRAY + "[" +
            EnumChatFormatting.RED       + "Gatau" +
            EnumChatFormatting.DARK_GRAY + "] " +
            EnumChatFormatting.RESET;

    /**
     * Sends a coloured message to the player's chat (client-side only).
     * Supports Minecraft colour codes with {@code &} as the prefix character.
     */
    public static void sendMessage(String message) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        String formatted = PREFIX + message.replace("&", "\u00a7");
        mc.thePlayer.addChatMessage(new ChatComponentText(formatted));
    }

    /** Send a plain message without the Gatau prefix. */
    public static void sendRaw(String message) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null) return;
        mc.thePlayer.addChatMessage(new ChatComponentText(message.replace("&", "\u00a7")));
    }
}
