package com.gatauc.client.utils;

import java.awt.Color;

/**
 * Color utility helpers for ARGB manipulation and animated color effects.
 */
public class ColorUtils {

    /** Gatau Client primary red (#FF3030) */
    public static final int RED     = 0xFFFF3030;
    public static final int RED_DIM = 0xAAFF3030;

    /** Dark background used in the GUI */
    public static final int BG_DARK   = 0xFF1A1A1A;
    public static final int BG_MEDIUM = 0xFF252525;
    public static final int BG_LIGHT  = 0xFF333333;

    /** Text colors */
    public static final int TEXT_WHITE = 0xFFFFFFFF;
    public static final int TEXT_GRAY  = 0xFFAAAAAA;
    public static final int TEXT_RED   = 0xFFFF3030;

    // ── Manipulation ─────────────────────────────────────────────────────────

    public static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    public static int lerp(int colorA, int colorB, float t) {
        int ar = (colorA >> 16) & 0xFF;
        int ag = (colorA >> 8)  & 0xFF;
        int ab = (colorA)       & 0xFF;
        int aa = (colorA >> 24) & 0xFF;

        int br = (colorB >> 16) & 0xFF;
        int bg = (colorB >> 8)  & 0xFF;
        int bb = (colorB)       & 0xFF;
        int ba = (colorB >> 24) & 0xFF;

        int r = (int)(ar + (br - ar) * t);
        int g = (int)(ag + (bg - ag) * t);
        int b = (int)(ab + (bb - ab) * t);
        int a = (int)(aa + (ba - aa) * t);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /**
     * Returns a pulsing red color based on system time.
     * Useful for glowing accents in the GUI.
     */
    public static int pulsingRed() {
        float pulse = (float)(Math.sin(System.currentTimeMillis() / 600.0) * 0.5 + 0.5);
        int alpha   = (int)(180 + pulse * 75);
        return withAlpha(RED, alpha);
    }

    /** Convert HSB to ARGB integer. */
    public static int hsb(float hue, float sat, float bri) {
        int rgb = Color.HSBtoRGB(hue, sat, bri);
        return 0xFF000000 | (rgb & 0xFFFFFF);
    }

    /** Rainbow color cycling — returns ARGB based on time offset. */
    public static int rainbow(int offset) {
        long time  = System.currentTimeMillis();
        float hue  = ((time + offset) % 2000) / 2000.0f;
        return hsb(hue, 1.0f, 1.0f);
    }
}
