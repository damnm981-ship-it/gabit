package com.gatauc.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import org.lwjgl.opengl.GL11;

/**
 * General-purpose 2D drawing helpers for HUD and GUI rendering.
 */
public class DrawUtils {

    // ── Rectangles ────────────────────────────────────────────────────────────

    /** Draw a solid ARGB filled rectangle. */
    public static void drawRect(int x, int y, int w, int h, int color) {
        Gui.drawRect(x, y, x + w, y + h, color);
    }

    /** Draw a rectangle with a 1-pixel border of the given colour. */
    public static void drawBorder(int x, int y, int w, int h, int borderColor, int fillColor) {
        drawRect(x, y, w, h, fillColor);
        drawRect(x,         y,         w, 1, borderColor); // top
        drawRect(x,         y + h - 1, w, 1, borderColor); // bottom
        drawRect(x,         y,         1, h, borderColor); // left
        drawRect(x + w - 1, y,         1, h, borderColor); // right
    }

    /**
     * Draw a rounded rectangle using GL11 triangle fans.
     *
     * @param radius corner radius in pixels (max 8 recommended)
     */
    public static void drawRoundedRect(float x, float y, float w, float h, float radius, int color) {
        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.color(r, g, b, a);

        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        drawArc(x + radius,         y + radius,         radius, 180, 270);
        drawArc(x + w - radius,     y + radius,         radius, 270, 360);
        drawArc(x + w - radius,     y + h - radius,     radius,   0,  90);
        drawArc(x + radius,         y + h - radius,     radius,  90, 180);
        GL11.glEnd();

        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private static void drawArc(float cx, float cy, float radius, int startDeg, int endDeg) {
        for (int i = startDeg; i <= endDeg; i += 4) {
            double rad = Math.toRadians(i);
            GL11.glVertex2f(cx + (float) Math.cos(rad) * radius,
                            cy + (float) Math.sin(rad) * radius);
        }
    }

    // ── Lines ────────────────────────────────────────────────────────────────

    public static void drawLine(int x1, int y1, int x2, int y2, int thickness, int color) {
        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glLineWidth(thickness);
        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    // ── Circles ──────────────────────────────────────────────────────────────

    public static void drawFilledCircle(int cx, int cy, float radius, int color) {
        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(cx, cy);
        for (int i = 0; i <= 360; i += 4) {
            double rad = Math.toRadians(i);
            GL11.glVertex2f(cx + (float) Math.cos(rad) * radius,
                            cy + (float) Math.sin(rad) * radius);
        }
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawCircle(int cx, int cy, float radius, float lineWidth, int color) {
        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GL11.glLineWidth(lineWidth);
        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        for (int i = 0; i <= 360; i += 4) {
            double rad = Math.toRadians(i);
            GL11.glVertex2f(cx + (float) Math.cos(rad) * radius,
                            cy + (float) Math.sin(rad) * radius);
        }
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static void drawArrow(int cx, int cy, int size, int color) {
        // Simple downward pointing arrow
        drawLine(cx, cy - size, cx, cy + size, 1, color);
        drawLine(cx - size / 2, cy, cx, cy + size, 1, color);
        drawLine(cx + size / 2, cy, cx, cy + size, 1, color);
    }

    // ── Item stacks ──────────────────────────────────────────────────────────

    public static void drawItemStack(ItemStack stack, int x, int y) {
        if (stack == null) return;
        RenderHelper.enableGUIStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        Minecraft.getMinecraft().getRenderItem().renderItemOverlayIntoGUI(
                Minecraft.getMinecraft().fontRendererObj, stack, x, y, null);
        RenderHelper.disableStandardItemLighting();
    }

    // ── Gradient ────────────────────────────────────────────────────────────

    /** Draw a horizontal gradient rectangle. */
    public static void drawGradientRect(int x, int y, int w, int h, int colorLeft, int colorRight) {
        float al = ((colorLeft  >> 24) & 0xFF) / 255.0f;
        float rl = ((colorLeft  >> 16) & 0xFF) / 255.0f;
        float gl = ((colorLeft  >> 8)  & 0xFF) / 255.0f;
        float bl = ((colorLeft)        & 0xFF) / 255.0f;

        float ar = ((colorRight >> 24) & 0xFF) / 255.0f;
        float rr = ((colorRight >> 16) & 0xFF) / 255.0f;
        float gr = ((colorRight >> 8)  & 0xFF) / 255.0f;
        float br = ((colorRight)       & 0xFF) / 255.0f;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glBegin(GL11.GL_QUADS);
        GL11.glColor4f(rl, gl, bl, al);
        GL11.glVertex2f(x,     y);
        GL11.glVertex2f(x,     y + h);
        GL11.glColor4f(rr, gr, br, ar);
        GL11.glVertex2f(x + w, y + h);
        GL11.glVertex2f(x + w, y);
        GL11.glEnd();

        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}
