package com.gatauc.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

/**
 * Wrapper around Minecraft's FontRenderer for consistent text rendering
 * throughout the Gatau Client HUD and GUI.
 */
public class FontUtils {

    private static FontRenderer fr() {
        return Minecraft.getMinecraft().fontRendererObj;
    }

    // ── Drawing ──────────────────────────────────────────────────────────────

    public static void drawString(String text, int x, int y, int color) {
        fr().drawStringWithShadow(text, x, y, color);
    }

    public static void drawStringNoShadow(String text, int x, int y, int color) {
        fr().drawString(text, x, y, color);
    }

    public static void drawCenteredString(String text, int cx, int y, int color) {
        int x = cx - fr().getStringWidth(text) / 2;
        fr().drawStringWithShadow(text, x, y, color);
    }

    public static void drawRightAlignedString(String text, int rightX, int y, int color) {
        int x = rightX - fr().getStringWidth(text);
        fr().drawStringWithShadow(text, x, y, color);
    }

    // ── Measurement ──────────────────────────────────────────────────────────

    public static int getStringWidth(String text)  { return fr().getStringWidth(text); }
    public static int getCharHeight()              { return fr().FONT_HEIGHT; }
}
