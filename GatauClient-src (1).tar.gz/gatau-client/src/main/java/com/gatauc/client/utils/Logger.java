package com.gatauc.client.utils;

import com.gatauc.client.GatauClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Simple logging wrapper that prefixes all messages with "[GatauClient]".
 */
public class Logger {

    private static final org.apache.logging.log4j.Logger LOG =
            LogManager.getLogger(GatauClient.NAME);

    public static void info (String msg) { LOG.info ("[GatauClient] " + msg); }
    public static void warn (String msg) { LOG.warn ("[GatauClient] " + msg); }
    public static void error(String msg) { LOG.error("[GatauClient] " + msg); }
    public static void debug(String msg) { LOG.debug("[GatauClient] " + msg); }
}
