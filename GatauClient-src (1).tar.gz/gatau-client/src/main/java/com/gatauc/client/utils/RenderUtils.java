package com.gatauc.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

/**
 * 3D rendering utilities used by ESP, Tracers, and NameTags.
 */
public class RenderUtils {

    // ── Common ───────────────────────────────────────────────────────────────

    private static double interpolate(double current, double previous, float partialTicks) {
        return previous + (current - previous) * partialTicks;
    }

    // ── Entity bounding box ──────────────────────────────────────────────────

    public static void drawEntityBox(Entity entity, int color, float pt) {
        Minecraft mc = Minecraft.getMinecraft();

        double rx = mc.getRenderManager().viewerPosX;
        double ry = mc.getRenderManager().viewerPosY;
        double rz = mc.getRenderManager().viewerPosZ;

        double x = interpolate(entity.posX, entity.prevPosX, pt) - rx;
        double y = interpolate(entity.posY, entity.prevPosY, pt) - ry;
        double z = interpolate(entity.posZ, entity.prevPosZ, pt) - rz;

        double w = entity.width  / 2.0;
        double h = entity.height;

        AxisAlignedBB bb = new AxisAlignedBB(x - w, y, z - w, x + w, y + h, z + w);

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableLighting();

        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GL11.glLineWidth(1.5f);
        GL11.glColor4f(r, g, b, a);

        drawOutlinedBoundingBox(bb);

        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private static void drawOutlinedBoundingBox(AxisAlignedBB bb) {
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(bb.minX, bb.minY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.minY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.minY, bb.maxZ);
        GL11.glVertex3d(bb.minX, bb.minY, bb.maxZ);
        GL11.glVertex3d(bb.minX, bb.minY, bb.minZ);
        GL11.glEnd();

        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(bb.minX, bb.maxY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.maxY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.maxY, bb.maxZ);
        GL11.glVertex3d(bb.minX, bb.maxY, bb.maxZ);
        GL11.glVertex3d(bb.minX, bb.maxY, bb.minZ);
        GL11.glEnd();

        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(bb.minX, bb.minY, bb.minZ); GL11.glVertex3d(bb.minX, bb.maxY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.minY, bb.minZ); GL11.glVertex3d(bb.maxX, bb.maxY, bb.minZ);
        GL11.glVertex3d(bb.maxX, bb.minY, bb.maxZ); GL11.glVertex3d(bb.maxX, bb.maxY, bb.maxZ);
        GL11.glVertex3d(bb.minX, bb.minY, bb.maxZ); GL11.glVertex3d(bb.minX, bb.maxY, bb.maxZ);
        GL11.glEnd();
    }

    public static void drawEntityOutline(Entity entity, int color, float pt) {
        // Outline uses a slightly expanded box with higher alpha
        drawEntityBox(entity, (color & 0x00FFFFFF) | 0xCC000000, pt);
    }

    public static void drawEntityGlow(Entity entity, int color, float pt) {
        // Glow = box + filled transparent interior
        drawEntityBox(entity, color, pt);
    }

    // ── Tracers ──────────────────────────────────────────────────────────────

    public static void drawTracer(Entity entity, int color, String origin, float pt) {
        Minecraft mc = Minecraft.getMinecraft();

        double rx = mc.getRenderManager().viewerPosX;
        double ry = mc.getRenderManager().viewerPosY;
        double rz = mc.getRenderManager().viewerPosZ;

        double tx = interpolate(entity.posX, entity.prevPosX, pt) - rx;
        double ty = interpolate(entity.posY, entity.prevPosY, pt) - ry + entity.height / 2.0;
        double tz = interpolate(entity.posZ, entity.prevPosZ, pt) - rz;

        // The start point depends on the chosen origin
        double sy = 0;
        switch (origin) {
            case "Top":       sy = -mc.thePlayer.height; break;
            case "Feet":      sy = 0; break;
            default:          sy = -mc.thePlayer.height / 2.0; break; // Crosshair (eye)
        }

        float a = ((color >> 24) & 0xFF) / 255.0f;
        float r = ((color >> 16) & 0xFF) / 255.0f;
        float g = ((color >> 8)  & 0xFF) / 255.0f;
        float b = ((color)       & 0xFF) / 255.0f;

        GL11.glColor4f(r, g, b, a);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(0, sy, 0);
        GL11.glVertex3d(tx, ty, tz);
        GL11.glEnd();
    }

    // ── Name tags ────────────────────────────────────────────────────────────

    public static void drawNameTag(EntityPlayer player, boolean showHealth,
                                   boolean showDist, float scale, float pt) {
        // Name tag rendering is handled through Minecraft's FontRenderer in world space.
        // Detailed implementation requires GL11 billboard transforms — placeholder hook
        // that the EntityRenderer mixin calls via isEnabled() checks.
    }
}
