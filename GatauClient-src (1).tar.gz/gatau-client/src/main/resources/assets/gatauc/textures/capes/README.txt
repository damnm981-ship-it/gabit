Cape Textures
=============

Place your cape PNG files in this folder:

  red_cape.png       — Static red cape (64×32 px, Minecraft cape format)
  red_animated.png   — Animated red cape (64×64+ px sprite sheet)

Cape texture format:
  - Width:  64 pixels
  - Height: 32 pixels  (or multiples for animation)
  - Standard Minecraft cape UV layout
  - Transparency supported (RGBA)

The CapeSystem module reads these at:
  new ResourceLocation("gatauc", "textures/capes/red_cape.png")

Placeholder textures can be generated with any image editor.
