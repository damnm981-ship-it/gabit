Logo Textures
=============

Place the Gatau Client logo PNG here:

  logo.png           — Main menu logo (recommended 256×64 px, transparent background)
  logo_small.png     — Small version for in-game overlays (64×16 px)

The logo is referenced in:
  - mcmod.info  → "logoFile": "assets/gatauc/textures/logo.png"
  - GatauMainMenu draws it procedurally using FontUtils (text-based logo)
    Replace with texture rendering if you add a proper image asset.

Recommended tool: Photoshop / GIMP / paint.net
Font suggestion: "Minecraft" or a bold sans-serif
Primary colour: #FF3030 (red) on transparent/dark background
